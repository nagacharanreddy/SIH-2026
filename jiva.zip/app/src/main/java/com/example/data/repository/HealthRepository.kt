package com.example.data.repository

import com.example.data.local.*
import com.example.data.models.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class HealthRepository(
    private val jivaDao: JivaDao,
    private val repositoryScope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {

    companion object {
        @Volatile
        private var INSTANCE: HealthRepository? = null

        fun getInstance(jivaDao: JivaDao): HealthRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = HealthRepository(jivaDao)
                INSTANCE = instance
                instance
            }
        }
    }

    // Reactive StateFlows for UI
    private val _vitals = MutableStateFlow(VitalReading())
    val vitals: StateFlow<VitalReading> = _vitals.asStateFlow()
    val liveVitals: StateFlow<VitalReading> = _vitals.asStateFlow()

    private val _environment = MutableStateFlow(EnvironmentalReading())
    val environment: StateFlow<EnvironmentalReading> = _environment.asStateFlow()
    val liveEnvironment: StateFlow<EnvironmentalReading> = _environment.asStateFlow()

    private val _baseline = MutableStateFlow(PersonalBaseline())
    val baseline: StateFlow<PersonalBaseline> = _baseline.asStateFlow()
    val personalBaseline: StateFlow<PersonalBaseline> = _baseline.asStateFlow()

    private val _riskScore = MutableStateFlow(RiskScoreData())
    val riskScore: StateFlow<RiskScoreData> = _riskScore.asStateFlow()
    val liveRiskScore: StateFlow<RiskScoreData> = _riskScore.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _continuity = MutableStateFlow(CareContinuityMetrics())
    val continuity: StateFlow<CareContinuityMetrics> = _continuity.asStateFlow()

    private val _conditions = MutableStateFlow<List<ConditionItem>>(emptyList())
    val conditions: StateFlow<List<ConditionItem>> = _conditions.asStateFlow()

    private val _carePlans = MutableStateFlow<List<CarePlanItem>>(emptyList())
    val carePlans: StateFlow<List<CarePlanItem>> = _carePlans.asStateFlow()

    private val _activeCarePlan = MutableStateFlow<CarePlanItem?>(CarePlanItem())
    val activeCarePlan: StateFlow<CarePlanItem?> = _activeCarePlan.asStateFlow()

    private val _carePlanHistory = MutableStateFlow<List<CarePlanVersionHistory>>(emptyList())
    val carePlanHistory: StateFlow<List<CarePlanVersionHistory>> = _carePlanHistory.asStateFlow()

    private val _medications = MutableStateFlow<List<MedicationItem>>(emptyList())
    val medications: StateFlow<List<MedicationItem>> = _medications.asStateFlow()

    private val _adherenceRate = MutableStateFlow(94)
    val adherenceRate: StateFlow<Int> = _adherenceRate.asStateFlow()

    private val _symptoms = MutableStateFlow<List<SymptomEntry>>(emptyList())
    val symptoms: StateFlow<List<SymptomEntry>> = _symptoms.asStateFlow()

    private val _alerts = MutableStateFlow<List<AlertItem>>(emptyList())
    val alerts: StateFlow<List<AlertItem>> = _alerts.asStateFlow()

    private val _timeline = MutableStateFlow<List<HealthTimelineEvent>>(emptyList())
    val timeline: StateFlow<List<HealthTimelineEvent>> = _timeline.asStateFlow()

    private val _doctors = MutableStateFlow<List<DoctorInfo>>(emptyList())
    val doctors: StateFlow<List<DoctorInfo>> = _doctors.asStateFlow()

    private val _isOfflineMode = MutableStateFlow(false)
    val isOfflineMode: StateFlow<Boolean> = _isOfflineMode.asStateFlow()

    private var activePreset = "NORMAL"

    init {
        seedInitialData()
        startLiveSensorStream()
    }

    private fun seedInitialData() {
        val initialConditions = listOf(
            ConditionItem(
                id = "cond_1",
                name = "Bronchial Asthma & Cardiac Wellness",
                category = "Respiratory & Cardiovascular",
                diagnosisDate = "12 Jan 2024",
                severity = "Moderate",
                treatingDoctor = "Dr. Ananya Roy, MD",
                hospital = "Apollo Health City",
                status = "Active Monitoring",
                primaryVitals = listOf("SpO₂", "Heart Rate", "AQI"),
                warningSigns = listOf("SpO₂ < 93%", "Wheezing on exertion", "Sudden nocturnal dyspnea"),
                followUpSchedule = "Every 3 Months"
            ),
            ConditionItem(
                id = "cond_2",
                name = "Mild Cardiac Arrhythmia (PAC)",
                category = "Cardiovascular",
                diagnosisDate = "05 Mar 2023",
                severity = "Low",
                treatingDoctor = "Dr. Sameer Kulkarni",
                hospital = "Fortis Heart Institute",
                status = "Continuous Telemetry",
                primaryVitals = listOf("Heart Rate", "ECG Waveform", "HRV"),
                warningSigns = listOf("HR > 120 resting", "Palpitations in heat"),
                followUpSchedule = "Bi-annual review"
            )
        )
        _conditions.value = initialConditions

        val initialCarePlan = CarePlanItem(
            id = "cp_1",
            title = "Asthma & Cardiac Adaptive Protocol",
            conditionName = "Asthma / Cardiac Wellness",
            doctorName = "Dr. Ananya Roy, MD",
            version = "v2.4",
            lastUpdated = "Today (Synced)",
            monitoringFrequency = "Twice Daily + Exertion",
            vitalsToMonitor = listOf("Heart Rate", "SpO₂", "AQI", "Heat Index"),
            symptomsToMonitor = listOf("Chest tightness", "Fatigue", "Shortness of breath"),
            activityGuidance = "Target 7,500 daily steps. Keep hydrated if ambient temperature exceeds 35°C.",
            doctorNotes = "Strict compliance on Salbutamol timing during high AQI days. Vitals stabilizing well.",
            medications = listOf("Salbutamol 100mcg", "Atorvastatin 20mg", "Metformin 500mg"),
            isAcknowledged = true,
            isAcknowledgedByPatient = true
        )
        _activeCarePlan.value = initialCarePlan
        _carePlans.value = listOf(initialCarePlan)

        _carePlanHistory.value = listOf(
            CarePlanVersionHistory("v2.4", "Today", "Dr. Ananya Roy, MD", "Adjusted Salbutamol protocol for heatwave conditions.", true),
            CarePlanVersionHistory("v2.3", "10 Jul 2026", "Dr. Ananya Roy, MD", "Added nightly telemetry monitoring.", true)
        )

        val initialMeds = listOf(
            MedicationItem(
                id = "med_1",
                name = "Salbutamol Inhaler",
                dosage = "100 mcg",
                frequency = "Twice daily",
                scheduledTime = "08:00 AM",
                instructions = "1 puff in the morning; rinse mouth with water.",
                conditionTag = "Asthma",
                status = MedicationStatus.DUE_NOW,
                adherenceRate = 96
            ),
            MedicationItem(
                id = "med_2",
                name = "Atorvastatin",
                dosage = "20 mg",
                frequency = "Once daily (Night)",
                scheduledTime = "09:00 PM",
                instructions = "Take after dinner with water.",
                conditionTag = "Cardiac Health",
                status = MedicationStatus.UPCOMING,
                adherenceRate = 94
            ),
            MedicationItem(
                id = "med_3",
                name = "Metformin HCl",
                dosage = "500 mg",
                frequency = "Twice daily",
                scheduledTime = "08:30 PM",
                instructions = "Take immediately with meal.",
                conditionTag = "Metabolic",
                status = MedicationStatus.UPCOMING,
                adherenceRate = 92
            )
        )
        _medications.value = initialMeds

        _symptoms.value = listOf(
            SymptomEntry("sym_1", "Fatigue", 2, 1, 2, 0, 1, 8, 7, 8, "STABLE", 0, "Feeling energetic today"),
            SymptomEntry("sym_2", "Shortness of Breath", 1, 0, 1, 0, 1, 8, 8, 8, "STABLE", 0, "No airway resistance")
        )

        _alerts.value = listOf(
            AlertItem(
                id = "alt_1",
                title = "Baseline Alignment Verified",
                severity = RiskLevel.LOW,
                message = "All monitored physiological and environmental vitals are within your personal calibrated baseline thresholds.",
                factors = listOf("Resting HR 78 BPM (normal)", "SpO₂ 98%", "Safe AQI index (42)"),
                timestamp = "Today, 08:15 AM",
                recommendedAction = "Continue regular daily care routine and planned hydration."
            )
        )

        _timeline.value = listOf(
            HealthTimelineEvent("ev_1", "Today", "08:30 AM", "Morning Vital Check Completed", "Heart Rate 78 BPM, SpO2 98%, Temp 36.8°C. Stable baseline.", "Vitals", "Stable"),
            HealthTimelineEvent("ev_2", "Today", "08:00 AM", "Medication Administered", "Salbutamol Inhaler 100mcg taken on schedule.", "Medication", "Stable"),
            HealthTimelineEvent("ev_3", "Yesterday", "09:00 PM", "Evening Check-in Recorded", "Symptom score 1/10. No adverse cardiac signals.", "Care Plan", "Stable")
        )

        _doctors.value = listOf(
            DoctorInfo("doc_1", "Dr. Ananya Roy, MD", "Pulmonologist & Critical Care", "Apollo Health City", "Respiratory Dept", "+91 98112 54320", "dr.ananya@apollohealth.org", true, "Today, 4:30 PM"),
            DoctorInfo("doc_2", "Dr. Sameer Kulkarni", "Senior Cardiologist", "Fortis Escorts Heart Inst.", "Cardiology", "+91 99340 12098", "dr.kulkarni@fortis.org", true, "Thursday, 2:00 PM")
        )
    }

    private fun startLiveSensorStream() {
        repositoryScope.launch {
            var tick = 0
            while (isActive) {
                delay(3000)
                tick++
                if (_userProfile.value.isMonitoringActive) {
                    when (activePreset) {
                        "NORMAL" -> {
                            val hrNoise = (Math.sin(tick * 0.4) * 3).toInt()
                            val currentHr = (78 + hrNoise).coerceIn(68, 86)
                            _vitals.value = _vitals.value.copy(
                                heartRate = currentHr,
                                spO2 = 98,
                                hrv = 52 + (Math.cos(tick * 0.3) * 4).toInt(),
                                skinTemp = 36.8f,
                                bloodPressureSys = 118,
                                bloodPressureDia = 78,
                                bloodGlucose = 95 + (tick % 3),
                                respirationRate = 16,
                                timestamp = System.currentTimeMillis()
                            )
                        }
                        "HEAT_STRESS" -> {
                            val currentHr = (108 + (Math.sin(tick * 0.5) * 4).toInt()).coerceIn(100, 118)
                            _vitals.value = _vitals.value.copy(
                                heartRate = currentHr,
                                spO2 = 96,
                                hrv = 28,
                                skinTemp = 38.4f,
                                bloodPressureSys = 138,
                                bloodPressureDia = 88,
                                respirationRate = 22,
                                timestamp = System.currentTimeMillis()
                            )
                        }
                        "POLLUTION" -> {
                            _vitals.value = _vitals.value.copy(
                                heartRate = 92 + (tick % 4),
                                spO2 = 93,
                                respirationRate = 24,
                                hrv = 34,
                                timestamp = System.currentTimeMillis()
                            )
                        }
                        "CRITICAL" -> {
                            val currentHr = (134 + (Math.sin(tick * 0.6) * 5).toInt()).coerceIn(125, 145)
                            _vitals.value = _vitals.value.copy(
                                heartRate = currentHr,
                                spO2 = 89,
                                hrv = 18,
                                skinTemp = 39.1f,
                                bloodPressureSys = 168,
                                bloodPressureDia = 104,
                                respirationRate = 28,
                                timestamp = System.currentTimeMillis()
                            )
                        }
                    }
                    evaluateRiskEngine()
                }
            }
        }
    }

    private fun evaluateRiskEngine() {
        val v = _vitals.value
        val e = _environment.value
        val b = _baseline.value

        var score = 15
        val factors = mutableListOf<String>()
        val recommendations = mutableListOf<String>()

        // HR evaluation vs personal baseline
        if (v.heartRate > b.heartRateNormalMax) {
            val delta = v.heartRate - b.heartRateNormalMax
            score += (delta * 1.5f).toInt()
            factors.add("Heart rate is +$delta BPM above your 30-day personal baseline (${b.heartRateNormalMax} BPM)")
            recommendations.add("Rest in a well-ventilated space and reduce physical exertion")
        } else {
            factors.add("Heart rate is well within personal baseline (${b.heartRateNormalMin}-${b.heartRateNormalMax} BPM)")
        }

        // SpO2 evaluation
        if (v.spO2 < b.spO2NormalMin) {
            val spDelta = b.spO2NormalMin - v.spO2
            score += spDelta * 10
            factors.add("SpO₂ oxygen saturation (${v.spO2}%) is below your normal baseline (≥${b.spO2NormalMin}%)")
            recommendations.add("Practice slow diaphragmatic breathing; seek medical guidance if breathing effort increases")
        }

        // Environment + Temperature combination
        if (e.heatIndex > 38.0f || v.skinTemp > 38.0f) {
            score += 25
            factors.add("Combined high environmental heat index (${e.heatIndex}°C) and elevated skin temperature (${v.skinTemp}°C)")
            recommendations.add("Immediate hydration with electrolyte fluids and move into an air-conditioned room")
        }

        // AQI evaluation
        if (e.aqi > 150) {
            score += 20
            factors.add("Elevated particulate pollution (AQI ${e.aqi}) poses heightened respiratory stress")
            recommendations.add("Wear an N95 mask if outdoors or activate HEPA indoor air filtration")
        }

        score = score.coerceIn(5, 95)

        val (level, trend) = when {
            score < 30 -> Pair(RiskLevel.LOW, RiskTrend.STABLE)
            score <= 60 -> Pair(RiskLevel.MODERATE, RiskTrend.STABLE)
            score <= 80 -> Pair(RiskLevel.HIGH, RiskTrend.RISING)
            else -> Pair(RiskLevel.CRITICAL, RiskTrend.RISING)
        }

        val explanation = when (level) {
            RiskLevel.LOW -> "Your physiological parameters match your adaptive baseline. Environmental factors remain safe."
            RiskLevel.MODERATE -> "Mild variance detected from your baseline. Consider hydration and taking a brief rest."
            RiskLevel.HIGH -> "Health risk elevated due to cardiovascular load and external environmental stressors. Your care plan suggests notifying Dr. Ananya Roy."
            RiskLevel.CRITICAL -> "Urgent physiological variance detected. Immediate attention and doctor consultation strongly advised."
        }

        val score15 = (score + if (trend == RiskTrend.RISING) 4 else 0).coerceIn(0, 100)
        val score30 = (score + if (trend == RiskTrend.RISING) 9 else 0).coerceIn(0, 100)
        val score60 = (score + if (trend == RiskTrend.RISING) 14 else -2).coerceIn(0, 100)

        _riskScore.value = RiskScoreData(
            currentScore = score,
            score15Min = score15,
            score30Min = score30,
            score60Min = score60,
            level = level,
            trend = trend,
            contributingFactors = if (factors.isEmpty()) listOf("All readings stable") else factors,
            recommendations = if (recommendations.isEmpty()) listOf("Maintain current health habits", "Complete evening medication on time") else recommendations,
            explanation = explanation
        )

        if (score >= 65 && _alerts.value.none { it.severity == level && !it.isResolved }) {
            val newAlert = AlertItem(
                id = "alt_${System.currentTimeMillis()}",
                title = if (score >= 81) "CRITICAL HEALTH ALERT" else "Health Pattern Changed",
                severity = level,
                message = explanation,
                factors = factors.take(3),
                timestamp = "Just now",
                recommendedAction = recommendations.firstOrNull() ?: "Review active care plan"
            )
            _alerts.value = listOf(newAlert) + _alerts.value
        }
    }

    fun applyDemoPreset(preset: String) {
        activePreset = preset
        when (preset.uppercase()) {
            "NORMAL" -> {
                _environment.value = EnvironmentalReading(
                    temperature = 28.5f,
                    humidity = 55,
                    heatIndex = 30.0f,
                    aqi = 42,
                    aqiStatus = "Good",
                    locationName = "New Delhi, NCR"
                )
                _vitals.value = _vitals.value.copy(
                    heartRate = 78,
                    spO2 = 98,
                    hrv = 52,
                    skinTemp = 36.8f,
                    bloodPressureSys = 118,
                    bloodPressureDia = 78,
                    respirationRate = 16
                )
                _isOfflineMode.value = false
            }
            "HEAT", "HEAT_STRESS" -> {
                _environment.value = EnvironmentalReading(
                    temperature = 41.2f,
                    humidity = 78,
                    heatIndex = 48.5f,
                    aqi = 95,
                    aqiStatus = "Moderate",
                    locationName = "New Delhi, NCR"
                )
                _vitals.value = _vitals.value.copy(
                    heartRate = 108,
                    spO2 = 96,
                    hrv = 28,
                    skinTemp = 38.4f,
                    bloodPressureSys = 138,
                    bloodPressureDia = 88,
                    respirationRate = 22
                )
                _isOfflineMode.value = false
            }
            "POLLUTION" -> {
                _environment.value = EnvironmentalReading(
                    temperature = 31.0f,
                    humidity = 65,
                    heatIndex = 34.0f,
                    aqi = 285,
                    aqiStatus = "Severe",
                    locationName = "New Delhi, NCR"
                )
                _vitals.value = _vitals.value.copy(
                    heartRate = 92,
                    spO2 = 93,
                    hrv = 34,
                    skinTemp = 37.0f,
                    respirationRate = 24
                )
                _isOfflineMode.value = false
            }
            "CRITICAL" -> {
                _environment.value = EnvironmentalReading(
                    temperature = 39.0f,
                    humidity = 82,
                    heatIndex = 46.0f,
                    aqi = 190,
                    aqiStatus = "Unhealthy",
                    locationName = "New Delhi, NCR"
                )
                _vitals.value = _vitals.value.copy(
                    heartRate = 134,
                    spO2 = 89,
                    hrv = 18,
                    skinTemp = 39.1f,
                    bloodPressureSys = 168,
                    bloodPressureDia = 104,
                    respirationRate = 28
                )
                _isOfflineMode.value = false
            }
            "OFFLINE" -> {
                _isOfflineMode.value = true
            }
        }
        evaluateRiskEngine()
    }

    fun setDemoScenario(scenario: String) {
        applyDemoPreset(scenario)
    }

    fun takeMedication(medId: String) {
        markMedicationTaken(medId)
    }

    fun markMedicationTaken(medId: String) {
        _medications.value = _medications.value.map { med ->
            if (med.id == medId) {
                med.copy(status = MedicationStatus.TAKEN, adherenceRate = (med.adherenceRate + 1).coerceAtMost(100))
            } else med
        }
        updateContinuityScore()
        addTimelineEvent("Medication Taken", "Marked taken: ${_medications.value.find { it.id == medId }?.name}", "Medication")
    }

    fun addMedication(name: String, dosage: String, frequency: String, time: String) {
        val newMed = MedicationItem(
            name = name,
            dosage = dosage,
            frequency = frequency,
            scheduledTime = time,
            status = MedicationStatus.UPCOMING
        )
        _medications.value = _medications.value + newMed
        addTimelineEvent("Medication Added", "Prescription registered: $name ($dosage)", "Medication")
    }

    fun addCondition(name: String, category: String, severity: String) {
        val condition = ConditionItem(
            name = name,
            category = category,
            severity = severity
        )
        _conditions.value = _conditions.value + condition
        addTimelineEvent("Condition Added", "Added condition: $name", "Care Plan")
    }

    fun saveSymptomCheckIn(entry: SymptomEntry) {
        _symptoms.value = listOf(entry) + _symptoms.value
        addTimelineEvent("Daily Check-in Recorded", "Status: ${entry.overallStatus}. Notes: ${entry.notes}", "Care Plan")
        updateContinuityScore()
        evaluateRiskEngine()
    }

    fun updateCarePlanFromDoctor(
        title: String,
        medications: List<String>,
        updatedNotes: String,
        doctorName: String = "Dr. Ananya Roy, MD"
    ) {
        val currentPlan = _activeCarePlan.value
        val newVersion = "v2.5"

        val updated = currentPlan?.copy(
            title = title,
            version = newVersion,
            doctorNotes = updatedNotes,
            medications = medications,
            lastUpdated = "Today (Just now)",
            isAcknowledged = false,
            isAcknowledgedByPatient = false
        ) ?: CarePlanItem(
            title = title,
            version = newVersion,
            doctorNotes = updatedNotes,
            medications = medications,
            lastUpdated = "Today (Just now)",
            isAcknowledged = false,
            isAcknowledgedByPatient = false
        )

        _activeCarePlan.value = updated
        _carePlans.value = listOf(updated)

        val historyEntry = CarePlanVersionHistory(
            version = newVersion,
            date = "Today",
            updatedBy = doctorName,
            changeSummary = "Updated protocol: $title. Notes: $updatedNotes",
            patientAcknowledged = false
        )
        _carePlanHistory.value = listOf(historyEntry) + _carePlanHistory.value
        addTimelineEvent("Care Plan Updated by $doctorName", "Version $newVersion", "Care Plan")
    }

    fun acknowledgeCarePlan(planId: String = "cp_1") {
        _activeCarePlan.value = _activeCarePlan.value?.copy(isAcknowledged = true, isAcknowledgedByPatient = true)
        _carePlans.value = _carePlans.value.map {
            if (it.id == planId) it.copy(isAcknowledged = true, isAcknowledgedByPatient = true) else it
        }
        _carePlanHistory.value = _carePlanHistory.value.map {
            it.copy(patientAcknowledged = true)
        }
        addTimelineEvent("Care Plan Acknowledged", "Patient confirmed receipt of updated protocol.", "Care Plan")
    }

    fun toggleOfflineMode(offline: Boolean) {
        _isOfflineMode.value = offline
        _userProfile.value = _userProfile.value.copy(isOfflineMode = offline)
        val statusText = if (offline) "Offline mode activated. Local risk & monitoring continuing." else "Connection restored. Local engine synchronized."
        addTimelineEvent("Network Status Change", statusText, "Environment")
    }

    fun toggleMonitoring(active: Boolean) {
        _userProfile.value = _userProfile.value.copy(isMonitoringActive = active)
    }

    fun resolveAlert(alertId: String) {
        _alerts.value = _alerts.value.map {
            if (it.id == alertId) it.copy(isResolved = true) else it
        }
    }

    fun addTimelineEvent(title: String, description: String, category: String) {
        val newEvent = HealthTimelineEvent(
            id = "ev_${System.currentTimeMillis()}",
            dateString = "Today",
            timeString = "Just now",
            title = title,
            description = description,
            category = category,
            riskState = _riskScore.value.level.label
        )
        _timeline.value = listOf(newEvent) + _timeline.value
    }

    private fun updateContinuityScore() {
        val takenCount = _medications.value.count { it.status == MedicationStatus.TAKEN }
        val totalMeds = _medications.value.size.coerceAtLeast(1)
        val medPct = (takenCount * 100 / totalMeds).coerceIn(80, 100)
        _adherenceRate.value = medPct

        val overall = ((medPct * 0.4f) + (100 * 0.3f) + (91 * 0.2f) + (100 * 0.1f)).toInt()
        _continuity.value = CareContinuityMetrics(
            medicationAdherencePercent = medPct,
            symptomReportingPercent = 100,
            monitoringCompletionPercent = 91,
            appointmentAdherencePercent = 100,
            overallScorePercent = overall
        )
    }
}
