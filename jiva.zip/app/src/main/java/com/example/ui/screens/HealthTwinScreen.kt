package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun HealthTwinScreen(
    vitals: VitalReading,
    baseline: PersonalBaseline,
    riskScore: RiskScoreData,
    environment: EnvironmentalReading,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Overview, 1: Systems, 2: Baseline

    val statusColor = when (riskScore.level) {
        RiskLevel.LOW -> JivaGreenHealthy
        RiskLevel.MODERATE -> JivaAmberAttention
        RiskLevel.HIGH -> JivaOrangeHighRisk
        RiskLevel.CRITICAL -> JivaRedCritical
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                    }
                    Text(
                        text = "Adaptive Health Twin",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextPrimary
                        )
                    )
                }
                StatusBadge(status = riskScore.level.label, level = riskScore.level)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3D Visualizer Card
            GlassCard(
                cornerRadius = 28.dp,
                glowColor = statusColor,
                isAnimatedGlow = true,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "COMPUTATIONAL BIOMETRIC REPLICA",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTealPrimary,
                        letterSpacing = 1.sp
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Current State: ${riskScore.level.label.uppercase()}",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )

                // 3D Canvas
                HealthTwin3DCanvas(
                    riskLevel = riskScore.level,
                    heartRate = vitals.heartRate,
                    spO2 = vitals.spO2,
                    hrv = vitals.hrv,
                    temp = vitals.skinTemp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Considers: Personal Baseline • Real-time Vitals • Symptoms • Care Plans • Environment",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = JivaTextSecondary,
                        fontSize = 11.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Risk Trajectory Forecasting Card
            GlassCard(cornerRadius = 20.dp, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Early-Warning Risk Trajectory",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = JivaTealLight
                    ) {
                        Text(
                            text = "EARLY PREVIEW",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealDark,
                                fontSize = 9.sp
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    TrajectoryStep("CURRENT", "${riskScore.currentScore}", statusColor)
                    TrajectoryStep("+15 MIN", "${riskScore.score15Min}", JivaTealPrimary)
                    TrajectoryStep("+30 MIN", "${riskScore.score30Min}", JivaAmberAttention)
                    TrajectoryStep("+60 MIN", "${riskScore.score60Min}", JivaOrangeHighRisk)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Organ Systems Breakdown
            SectionHeader(title = "Organ Systems Telemetry")

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SystemCard(
                    systemName = "Cardiovascular & Endothelial",
                    status = if (vitals.heartRate > 100) "Elevated Load" else "Optimal Rhythm",
                    details = "HR: ${vitals.heartRate} BPM • BP: ${vitals.bloodPressureSys}/${vitals.bloodPressureDia} • HRV: ${vitals.hrv}ms",
                    icon = Icons.Default.Favorite,
                    accent = if (vitals.heartRate > 100) JivaOrangeHighRisk else JivaGreenHealthy
                )
                SystemCard(
                    systemName = "Respiratory & Pulmonary",
                    status = if (vitals.spO2 < 95) "Attention" else "Stable Oxygenation",
                    details = "SpO₂: ${vitals.spO2}% • Respiration: ${vitals.respirationRate}/min • AQI Filter: Active",
                    icon = Icons.Default.Air,
                    accent = if (vitals.spO2 < 95) JivaAmberAttention else JivaCyanAccent
                )
                SystemCard(
                    systemName = "Metabolic & Glucose Balance",
                    status = "Normal Post-Prandial",
                    details = "Glucose: ${vitals.bloodGlucose} mg/dL • Temp: ${vitals.skinTemp}°C • Hydration: Balanced",
                    icon = Icons.Default.Bolt,
                    accent = JivaPurpleInfo
                )
                SystemCard(
                    systemName = "Autonomic Nervous & Sleep",
                    status = "Restorative Phase",
                    details = "Sleep: ${vitals.sleepHours} hrs • Activity: ${vitals.activityLevel} • Stress Index: Low",
                    icon = Icons.Default.Bedtime,
                    accent = JivaTealPrimary
                )
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun TrajectoryStep(label: String, score: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = JivaTextSecondary,
                fontSize = 10.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f))
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = score,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
        }
    }
}

@Composable
private fun SystemCard(
    systemName: String,
    status: String,
    details: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color
) {
    GlassCard(cornerRadius = 18.dp, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = systemName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = details,
                    style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accent.copy(alpha = 0.12f)
            ) {
                Text(
                    text = status,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = accent
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
