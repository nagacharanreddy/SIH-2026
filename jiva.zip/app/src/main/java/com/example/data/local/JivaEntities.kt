package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vital_records")
data class LocalVitalRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val heartRate: Int,
    val spO2: Int,
    val hrv: Int,
    val skinTemp: Float,
    val bpSys: Int,
    val bpDia: Int,
    val bloodGlucose: Int,
    val respiration: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "conditions")
data class LocalCondition(
    @PrimaryKey val id: String,
    val name: String,
    val category: String,
    val diagnosisDate: String,
    val treatingDoctor: String,
    val hospital: String,
    val status: String,
    val primaryVitalsJoined: String,
    val warningSignsJoined: String,
    val followUpSchedule: String
)

@Entity(tableName = "medications")
data class LocalMedication(
    @PrimaryKey val id: String,
    val name: String,
    val dosage: String,
    val frequency: String,
    val scheduledTime: String,
    val instructions: String,
    val conditionTag: String,
    val status: String,
    val adherenceRate: Int
)

@Entity(tableName = "care_plans")
data class LocalCarePlan(
    @PrimaryKey val id: String,
    val title: String,
    val conditionName: String,
    val doctorName: String,
    val version: String,
    val lastUpdated: String,
    val monitoringFrequency: String,
    val vitalsJoined: String,
    val symptomsJoined: String,
    val activityGuidance: String,
    val doctorNotes: String,
    val isAcknowledged: Boolean
)

@Entity(tableName = "symptoms")
data class LocalSymptom(
    @PrimaryKey val id: String,
    val name: String,
    val severity: Int,
    val trendDelta: Int,
    val notes: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "alerts")
data class LocalAlert(
    @PrimaryKey val id: String,
    val title: String,
    val severity: String,
    val message: String,
    val factorsJoined: String,
    val timestamp: String,
    val recommendedAction: String,
    val isResolved: Boolean
)

@Entity(tableName = "timeline_events")
data class LocalTimelineEvent(
    @PrimaryKey val id: String,
    val dateString: String,
    val timeString: String,
    val title: String,
    val description: String,
    val category: String,
    val riskState: String,
    val actionTaken: String,
    val timestamp: Long = System.currentTimeMillis()
)
