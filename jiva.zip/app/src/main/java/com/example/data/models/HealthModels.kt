package com.example.data.models

enum class HealthStatus(val label: String) {
    GOOD("Good"),
    STABLE("Stable"),
    ATTENTION("Attention"),
    HIGH_RISK("High Risk"),
    CRITICAL("Critical")
}

enum class RiskLevel(val label: String, val colorHex: Long) {
    LOW("Low", 0xFF00A86B),
    MODERATE("Moderate", 0xFFF59E0B),
    HIGH("High", 0xFFEA580C),
    CRITICAL("Critical", 0xFFDC2626)
}

enum class RiskTrend {
    IMPROVING,
    STABLE,
    RISING
}

data class VitalReading(
    val heartRate: Int = 78,
    val spO2: Int = 98,
    val hrv: Int = 52,
    val skinTemp: Float = 36.8f,
    val bloodPressureSys: Int = 118,
    val bloodPressureDia: Int = 78,
    val bloodGlucose: Int = 95,
    val respirationRate: Int = 16,
    val activityLevel: String = "Moderate",
    val sleepHours: Float = 7.5f,
    val timestamp: Long = System.currentTimeMillis()
)

data class EnvironmentalReading(
    val temperature: Float = 28.5f,
    val humidity: Int = 62,
    val heatIndex: Float = 31.0f,
    val aqi: Int = 42,
    val aqiStatus: String = "Good",
    val pm25: Float = 18.5f,
    val pressureHpa: Int = 1013,
    val uvIndex: Int = 4,
    val locationName: String = "New Delhi, NCR",
    val timestamp: Long = System.currentTimeMillis()
)

data class PersonalBaseline(
    val heartRateNormalMin: Int = 60,
    val heartRateNormalMax: Int = 85,
    val spO2NormalMin: Int = 95,
    val hrvNormalMin: Int = 45,
    val skinTempNormalMin: Float = 36.2f,
    val skinTempNormalMax: Float = 37.2f,
    val bpSysNormalMax: Int = 125,
    val bpDiaNormalMax: Int = 82,
    val baselineProgressPercent: Int = 88,
    val isCalibrated: Boolean = true
)

data class RiskScoreData(
    val currentScore: Int = 18,
    val score15Min: Int = 20,
    val score30Min: Int = 22,
    val score60Min: Int = 21,
    val level: RiskLevel = RiskLevel.LOW,
    val trend: RiskTrend = RiskTrend.STABLE,
    val contributingFactors: List<String> = listOf(
        "Vitals align with your personal 30-day baseline",
        "Stable cardiac recovery index",
        "Optimal environmental temperature exposure"
    ),
    val recommendations: List<String> = listOf(
        "Maintain current hydration and gentle daily activity",
        "Scheduled evening symptom check-in at 8:00 PM"
    ),
    val explanation: String = "Your current vitals are well within your personal baseline. Environmental heat and air quality remain within safe parameters."
)

data class ConditionItem(
    val id: String = "cond_${System.currentTimeMillis()}",
    val name: String,
    val category: String,
    val diagnosisDate: String = "Today",
    val diagnosedDate: String = diagnosisDate,
    val severity: String = "Moderate",
    val treatingDoctor: String = "Dr. Ananya Roy, MD",
    val hospital: String = "Apollo Health City",
    val status: String = "Active Monitoring",
    val primaryVitals: List<String> = listOf("Heart Rate", "SpO₂"),
    val warningSigns: List<String> = listOf("Shortness of breath", "Elevated pulse"),
    val followUpSchedule: String = "Every 3 Months"
)

enum class MedicationStatus {
    UPCOMING,
    DUE_NOW,
    TAKEN,
    MISSED
}

data class MedicationItem(
    val id: String = "med_${System.currentTimeMillis()}",
    val name: String,
    val dosage: String,
    val frequency: String,
    val scheduledTime: String,
    val nextDueTime: String = scheduledTime,
    val instructions: String = "Take with water",
    val conditionTag: String = "General Care",
    val status: MedicationStatus = MedicationStatus.UPCOMING,
    val isDueNow: Boolean = (status == MedicationStatus.DUE_NOW),
    val isTaken: Boolean = (status == MedicationStatus.TAKEN),
    val adherenceRate: Int = 94
)

typealias CarePlan = CarePlanItem

data class CarePlanItem(
    val id: String = "cp_1",
    val title: String = "Cardiac & Respiratory Adaptive Care Plan",
    val conditionName: String = "Asthma / Cardiac Wellness",
    val doctorName: String = "Dr. Ananya Roy, MD",
    val version: String = "v2.4",
    val lastUpdated: String = "Today",
    val monitoringFrequency: String = "Twice daily",
    val vitalsToMonitor: List<String> = listOf("Heart Rate", "SpO₂", "AQI"),
    val symptomsToMonitor: List<String> = listOf("Chest tightness", "Fatigue", "Dyspnea"),
    val activityGuidance: String = "Moderate walking 30 min daily; avoid heavy outdoor exertion during AQI > 150.",
    val doctorNotes: String = "Maintain prescribed inhaler dosages. Keep hydration optimal on hot days.",
    val medications: List<String> = listOf("Salbutamol 100mcg", "Atorvastatin 20mg", "Metformin 500mg"),
    val isAcknowledged: Boolean = true,
    val isAcknowledgedByPatient: Boolean = true
)

data class CarePlanVersionHistory(
    val version: String,
    val date: String,
    val updatedBy: String,
    val changeSummary: String,
    val patientAcknowledged: Boolean
)

data class SymptomEntry(
    val id: String = "sym_${System.currentTimeMillis()}",
    val name: String = "Daily Check-in",
    val severity: Int = 2,
    val pain: Int = 1,
    val fatigue: Int = 2,
    val nausea: Int = 0,
    val breathing: Int = 1,
    val appetite: Int = 8,
    val sleepQuality: Int = 7,
    val mood: Int = 8,
    val overallStatus: String = "STABLE",
    val trendDelta: Int = 0,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class AlertItem(
    val id: String,
    val title: String,
    val severity: RiskLevel,
    val message: String,
    val factors: List<String>,
    val contributingParams: List<String> = factors,
    val timestamp: String,
    val recommendedAction: String,
    val isResolved: Boolean = false
)

data class HealthTimelineEvent(
    val id: String,
    val dateString: String,
    val timeString: String,
    val title: String,
    val description: String,
    val category: String,
    val riskState: String = "Stable",
    val actionTaken: String = ""
)

data class CareContinuityMetrics(
    val medicationAdherencePercent: Int = 94,
    val symptomReportingPercent: Int = 100,
    val monitoringCompletionPercent: Int = 91,
    val appointmentAdherencePercent: Int = 100,
    val overallScorePercent: Int = 92
)

data class DoctorInfo(
    val id: String,
    val name: String,
    val specialty: String,
    val hospital: String,
    val department: String,
    val phone: String,
    val email: String,
    val isOnline: Boolean = true,
    val nextAvailableSlot: String = "Today, 4:30 PM"
)

data class HealthReportData(
    val reportId: String,
    val generatedDate: String,
    val patientName: String,
    val period: String = "Last 14 Days",
    val primaryCondition: String,
    val medicationAdherence: Int,
    val averageHeartRate: Int,
    val averageSpO2: Int,
    val symptomSummary: String,
    val alertCount: Int,
    val riskTrajectory: String,
    val environmentalExposure: String,
    val keyObservations: List<String>,
    val doctorRecommendations: List<String>
)

data class UserProfile(
    val name: String = "Charan Sharma",
    val gender: String = "Male",
    val age: Int = 34,
    val dob: String = "14 Sep 1991",
    val heightCm: Int = 176,
    val weightKg: Float = 72.5f,
    val activityLevel: String = "Moderate Active",
    val averageSleepHours: Float = 7.5f,
    val emergencyContactName: String = "Priya Sharma (Spouse)",
    val emergencyContactPhone: String = "+91 98765 43210",
    val emergencyContact: String = "Priya Sharma (+91 98765 43210)",
    val bloodGroup: String = "O+ Positive",
    val careContinuityScore: Int = 92,
    val isOfflineMode: Boolean = false,
    val isMonitoringActive: Boolean = true
)
