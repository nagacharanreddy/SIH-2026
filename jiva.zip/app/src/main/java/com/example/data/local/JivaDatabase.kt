package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LocalVitalRecord::class,
        LocalCondition::class,
        LocalMedication::class,
        LocalCarePlan::class,
        LocalSymptom::class,
        LocalAlert::class,
        LocalTimelineEvent::class
    ],
    version = 1,
    exportSchema = false
)
abstract class JivaDatabase : RoomDatabase() {
    abstract fun jivaDao(): JivaDao

    companion object {
        @Volatile
        private var INSTANCE: JivaDatabase? = null

        fun getDatabase(context: Context): JivaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JivaDatabase::class.java,
                    "jiva_health_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
