package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.MedicationItem
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MedicationsScreen(
    medications: List<MedicationItem>,
    adherenceRate: Int,
    onTakeMedication: (String) -> Unit,
    onAddMedication: (String, String, String, String) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var medName by remember { mutableStateOf("") }
    var medDosage by remember { mutableStateOf("") }
    var medFreq by remember { mutableStateOf("Once daily") }
    var medTime by remember { mutableStateOf("08:00 AM") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                    }
                    Text(
                        text = "Medication Manager",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextPrimary
                        )
                    )
                }

                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(JivaTealLight)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Medication", tint = JivaTealPrimary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3D Capsule Hero & Adherence Card
            GlassCard(
                cornerRadius = 24.dp,
                glowColor = JivaTealPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "WEEKLY ADHERENCE SCORE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealPrimary,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "$adherenceRate%",
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = JivaGreenHealthy
                            )
                        )
                        Text(
                            text = "Excellent compliance with care plan",
                            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                        )
                    }

                    // 3D Capsule Canvas
                    Capsule3DCanvas(
                        isTaken = false,
                        isDueNow = true,
                        modifier = Modifier.size(100.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Daily Schedule
            SectionHeader(
                title = "Today's Prescriptions",
                subtitle = "Mark doses as taken to log adherence"
            )

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                medications.forEach { med ->
                    MedicationCard(
                        medication = med,
                        onTake = { onTakeMedication(med.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }

        // Add Med Dialog
        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Add Prescribed Medication", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = medName,
                            onValueChange = { medName = it },
                            label = { Text("Medication Name (e.g. Salbutamol)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = medDosage,
                            onValueChange = { medDosage = it },
                            label = { Text("Dosage (e.g. 100 mcg)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = medFreq,
                            onValueChange = { medFreq = it },
                            label = { Text("Frequency (e.g. Twice daily)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = medTime,
                            onValueChange = { medTime = it },
                            label = { Text("Next Due Time (e.g. 08:00 AM)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (medName.isNotBlank() && medDosage.isNotBlank()) {
                                onAddMedication(medName, medDosage, medFreq, medTime)
                                showAddDialog = false
                                medName = ""
                                medDosage = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = JivaTealPrimary)
                    ) {
                        Text("Add Medication")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun MedicationCard(
    medication: MedicationItem,
    onTake: () -> Unit
) {
    GlassCard(
        cornerRadius = 20.dp,
        glowColor = if (medication.isDueNow && !medication.isTaken) JivaCyanAccent else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (medication.isTaken) JivaGreenLight else JivaTealLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (medication.isTaken) Icons.Default.CheckCircle else Icons.Default.Medication,
                        contentDescription = null,
                        tint = if (medication.isTaken) JivaGreenHealthy else JivaTealPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "${medication.name} (${medication.dosage})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${medication.frequency} • Next: ${medication.nextDueTime}",
                        style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                    )
                    Text(
                        text = medication.instructions,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = JivaTealDark,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            if (!medication.isTaken) {
                Button(
                    onClick = onTake,
                    colors = ButtonDefaults.buttonColors(containerColor = JivaTealPrimary),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("take_med_btn_${medication.id}")
                ) {
                    Text(
                        text = "Take Dose",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = JivaGreenLight
                ) {
                    Text(
                        text = "TAKEN TODAY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaGreenHealthy,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
