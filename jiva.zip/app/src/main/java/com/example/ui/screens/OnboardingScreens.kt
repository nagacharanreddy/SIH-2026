package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ProfileSetupScreen(
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    var age by remember { mutableStateOf("34") }
    var height by remember { mutableStateOf("176") }
    var weight by remember { mutableStateOf("72.5") }
    var activityLevel by remember { mutableStateOf("Moderate") }
    var sleepHours by remember { mutableStateOf("7.5") }
    var emergencyContact by remember { mutableStateOf("+91 98765 43210 (Priya - Spouse)") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Profile & Biometrics",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = JivaTextPrimary
                )
            )

            Text(
                text = "Step 1 of 3 • Establishing your health foundation",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = JivaTealPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Explanation Card
            GlassCard(
                cornerRadius = 18.dp,
                glowColor = JivaTealPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = JivaTealPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Your baseline helps JIVA understand physiological deviations that are unusual for YOU, rather than generic population averages.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = JivaTextSecondary,
                            lineHeight = 18.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = age,
                        onValueChange = { age = it },
                        label = { Text("Age") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = height,
                        onValueChange = { height = it },
                        label = { Text("Height (cm)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    )
                    OutlinedTextField(
                        value = weight,
                        onValueChange = { weight = it },
                        label = { Text("Weight (kg)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = activityLevel,
                    onValueChange = { activityLevel = it },
                    label = { Text("Daily Activity Level") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = sleepHours,
                    onValueChange = { sleepHours = it },
                    label = { Text("Average Sleep (Hours)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = emergencyContact,
                    onValueChange = { emergencyContact = it },
                    label = { Text("Emergency Contact") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = JivaRedCritical) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                GlowButton(
                    text = "NEXT: SENSOR SETUP",
                    onClick = onNext,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "profile_setup_next_btn"
                )
            }
        }
    }
}

@Composable
fun SensorSetupScreen(
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSensor by remember { mutableStateOf("demo") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Sensor Configuration",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )

                Text(
                    text = "Step 2 of 3 • Connect telemetry streams",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = JivaTealPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                SensorOptionCard(
                    title = "DEMO TELEMETRY SENSOR",
                    desc = "Real-time simulated multi-stream sensors (HR, SpO₂, HRV, Temp, BP, Glucose, AQI).",
                    icon = Icons.Default.Sensors,
                    isSelected = selectedSensor == "demo",
                    onClick = { selectedSensor = "demo" }
                )

                Spacer(modifier = Modifier.height(12.dp))

                SensorOptionCard(
                    title = "SMARTWATCH / WEARABLE",
                    desc = "Pair via Bluetooth Low Energy (BLE) or Google Health Connect.",
                    icon = Icons.Default.Watch,
                    isSelected = selectedSensor == "wearable",
                    onClick = { selectedSensor = "wearable" }
                )

                Spacer(modifier = Modifier.height(12.dp))

                SensorOptionCard(
                    title = "PHONE SENSORS & GPS",
                    desc = "Step counter, ambient barometer, accelerometer, location thermal tracking.",
                    icon = Icons.Default.Smartphone,
                    isSelected = selectedSensor == "phone",
                    onClick = { selectedSensor = "phone" }
                )
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                GlowButton(
                    text = "NEXT: PERSONAL BASELINE",
                    onClick = onNext,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "sensor_setup_next_btn"
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun SensorOptionCard(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    GlassCard(
        cornerRadius = 20.dp,
        glowColor = if (isSelected) JivaTealPrimary else null,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) JivaTealLight else Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) JivaTealPrimary else JivaTextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) JivaTealDark else JivaTextPrimary
                    )
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                )
            }

            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = JivaTealPrimary)
            )
        }
    }
}

@Composable
fun BaselineSetupScreen(
    onFinish: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Personal Baseline",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )

                Text(
                    text = "LEARNING YOUR NORMAL",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = JivaTealPrimary,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Progress Bar Card
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Baseline Calibration",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "88% Calibrated",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaGreenHealthy
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { 0.88f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = JivaGreenHealthy,
                        trackColor = Color(0xFFE2E8F0)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "The baseline adapts continuously as new telemetry arrives without redefining acute deviations.",
                        style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Normal Bands Grid
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BaselineMetricRow("Resting Heart Rate", "60 – 85 BPM", "Current: 78 BPM", JivaGreenHealthy)
                    BaselineMetricRow("Oxygen Saturation (SpO₂)", "≥ 95%", "Current: 98%", JivaCyanAccent)
                    BaselineMetricRow("Heart Rate Variability", "≥ 45 ms", "Current: 52 ms", JivaPurpleInfo)
                    BaselineMetricRow("Skin Temperature", "36.2°C – 37.2°C", "Current: 36.8°C", JivaGreenHealthy)
                    BaselineMetricRow("Blood Pressure", "≤ 125/82 mmHg", "Current: 118/78", JivaTealPrimary)
                }
            }

            Column(modifier = Modifier.fillMaxWidth()) {
                GlowButton(
                    text = "ENTER JIVA DASHBOARD",
                    onClick = onFinish,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "baseline_enter_dashboard_btn"
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun BaselineMetricRow(
    metric: String,
    range: String,
    current: String,
    accent: Color
) {
    GlassCard(
        cornerRadius = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = metric,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Normal Range: $range",
                    style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                )
            }
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = accent.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.3f))
            ) {
                Text(
                    text = current,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = accent
                    ),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}
