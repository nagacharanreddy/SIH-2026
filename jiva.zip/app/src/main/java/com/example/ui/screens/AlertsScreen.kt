package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.AlertItem
import com.example.data.models.RiskLevel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun AlertsScreen(
    alerts: List<AlertItem>,
    onResolveAlert: (String) -> Unit,
    onNavigateEmergency: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(0) } // 0: All, 1: Active, 2: Resolved

    val filteredAlerts = remember(alerts, selectedFilter) {
        when (selectedFilter) {
            1 -> alerts.filter { !it.isResolved }
            2 -> alerts.filter { it.isResolved }
            else -> alerts
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Clinical Alerts",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextPrimary
                        )
                    )
                    Text(
                        text = "Real-time physiological anomaly warnings",
                        style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                    )
                }

                EmergencyButton(
                    onClick = onNavigateEmergency,
                    testTag = "alerts_emergency_btn"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Filter Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All Alerts", "Active Only", "Resolved History").forEachIndexed { index, title ->
                    val isSelected = selectedFilter == index
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) JivaTealPrimary else Color(0xFFF1F5F9),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        TextButton(
                            onClick = { selectedFilter = index },
                            contentPadding = PaddingValues(vertical = 6.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else JivaTextSecondary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (filteredAlerts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = JivaGreenHealthy,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No alerts in this category",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextPrimary
                            )
                        )
                        Text(
                            text = "Your physiological signals are within normal limits.",
                            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredAlerts, key = { it.id }) { alert ->
                        AlertCard(
                            alert = alert,
                            onResolve = { onResolveAlert(alert.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun AlertCard(
    alert: AlertItem,
    onResolve: () -> Unit
) {
    val severityColor = when (alert.severity) {
        RiskLevel.LOW -> JivaGreenHealthy
        RiskLevel.MODERATE -> JivaAmberAttention
        RiskLevel.HIGH -> JivaOrangeHighRisk
        RiskLevel.CRITICAL -> JivaRedCritical
    }

    GlassCard(
        cornerRadius = 20.dp,
        glowColor = if (!alert.isResolved) severityColor else null,
        isAnimatedGlow = alert.severity == RiskLevel.CRITICAL && !alert.isResolved,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(severityColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (alert.isResolved) Icons.Default.Check else Icons.Default.Warning,
                        contentDescription = null,
                        tint = severityColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = alert.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextPrimary
                        )
                    )
                    Text(
                        text = alert.timestamp,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = JivaTextTertiary,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            StatusBadge(
                status = if (alert.isResolved) "RESOLVED" else alert.severity.label,
                level = if (alert.isResolved) RiskLevel.LOW else alert.severity
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = alert.message,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = JivaTextPrimary,
                lineHeight = 20.sp
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Contributing Parameters Pill
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x80F1F5F9))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Tune, contentDescription = null, tint = JivaTealPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Trigger Factors: ${alert.contributingParams.joinToString(" • ")}",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = JivaTextSecondary,
                    fontSize = 11.sp
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Recommended Action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "RECOMMENDED ACTION:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTealPrimary,
                        fontSize = 10.sp
                    )
                )
                Text(
                    text = alert.recommendedAction,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = JivaTextPrimary
                    )
                )
            }

            if (!alert.isResolved) {
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onResolve,
                    colors = ButtonDefaults.buttonColors(containerColor = JivaTealPrimary),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("resolve_alert_btn_${alert.id}")
                ) {
                    Text(
                        text = "Resolve",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
