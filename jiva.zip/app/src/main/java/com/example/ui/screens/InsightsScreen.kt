package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun InsightsScreen(
    riskScore: RiskScoreData,
    vitals: VitalReading,
    environment: EnvironmentalReading,
    modifier: Modifier = Modifier
) {
    // Simulator states
    var simTemp by remember { mutableFloatStateOf(environment.temperature) }
    var simAqi by remember { mutableFloatStateOf(environment.aqi.toFloat()) }
    var simActivity by remember { mutableStateOf("Moderate") }
    var simMedsTaken by remember { mutableStateOf(true) }

    // Real-time calculation of simulated risk
    val calculatedSimRisk = remember(simTemp, simAqi, simActivity, simMedsTaken) {
        var base = 15
        if (simTemp > 38f) base += 25 else if (simTemp > 32f) base += 12
        if (simAqi > 200) base += 35 else if (simAqi > 100) base += 18
        if (simActivity == "High") base += 15 else if (simActivity == "Light") base -= 5
        if (!simMedsTaken) base += 20
        base.coerceIn(5, 95)
    }

    val simRiskLevel = when {
        calculatedSimRisk < 30 -> RiskLevel.LOW
        calculatedSimRisk < 60 -> RiskLevel.MODERATE
        calculatedSimRisk < 80 -> RiskLevel.HIGH
        else -> RiskLevel.CRITICAL
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Explainable AI & Insights",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = JivaTextPrimary
                )
            )

            Text(
                text = "Causal reasoning & proactive risk simulation",
                style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ==========================================
            // 1. RISK GAUGE & EXPLAINABILITY
            // ==========================================
            GlassCard(
                cornerRadius = 24.dp,
                glowColor = when (riskScore.level) {
                    RiskLevel.LOW -> JivaGreenHealthy
                    RiskLevel.MODERATE -> JivaAmberAttention
                    RiskLevel.HIGH -> JivaOrangeHighRisk
                    RiskLevel.CRITICAL -> JivaRedCritical
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "WHY DID MY RISK CHANGE?",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealPrimary,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (riskScore.contributingFactors.isEmpty())
                                "All vitals and environmental metrics remain securely within your calibrated baseline."
                            else
                                riskScore.contributingFactors.first(),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = JivaTextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }

                    RiskGaugeCanvas(
                        score = riskScore.currentScore,
                        level = riskScore.level,
                        modifier = Modifier.size(120.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Contributing factor pills
                Text(
                    text = "Contributing Physiological Factors:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextSecondary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    riskScore.contributingFactors.forEach { factor ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(JivaTealPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = factor,
                                style = MaterialTheme.typography.bodySmall.copy(color = JivaTextPrimary)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ==========================================
            // 2. INTERACTIVE WHAT-IF SIMULATOR
            // ==========================================
            SectionHeader(
                title = "What-If Risk Simulator",
                subtitle = "Explore how physiological & environmental changes impact your risk"
            )

            GlassCard(
                cornerRadius = 24.dp,
                glowColor = when (simRiskLevel) {
                    RiskLevel.LOW -> JivaGreenHealthy
                    RiskLevel.MODERATE -> JivaAmberAttention
                    RiskLevel.HIGH -> JivaOrangeHighRisk
                    RiskLevel.CRITICAL -> JivaRedCritical
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                // Disclaimer Banner
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFFEF3C7),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "SIMULATION ONLY • NOT A MEDICAL DIAGNOSIS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB45309),
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Simulated Output Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Simulated Risk Score",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "State: ${simRiskLevel.label.uppercase()}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = when (simRiskLevel) {
                                    RiskLevel.LOW -> JivaGreenHealthy
                                    RiskLevel.MODERATE -> JivaAmberAttention
                                    RiskLevel.HIGH -> JivaOrangeHighRisk
                                    RiskLevel.CRITICAL -> JivaRedCritical
                                },
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Text(
                        text = "$calculatedSimRisk / 100",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = JivaTextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Ambient Temperature Slider
                Text(
                    text = "Ambient Temperature: ${simTemp.toInt()}°C",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Slider(
                    value = simTemp,
                    onValueChange = { simTemp = it },
                    valueRange = 20f..45f,
                    colors = SliderDefaults.colors(
                        thumbColor = JivaTealPrimary,
                        activeTrackColor = JivaTealPrimary
                    ),
                    modifier = Modifier.testTag("sim_temp_slider")
                )

                // AQI Slider
                Text(
                    text = "Air Quality Index (AQI): ${simAqi.toInt()}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Slider(
                    value = simAqi,
                    onValueChange = { simAqi = it },
                    valueRange = 20f..350f,
                    colors = SliderDefaults.colors(
                        thumbColor = JivaCyanAccent,
                        activeTrackColor = JivaCyanAccent
                    ),
                    modifier = Modifier.testTag("sim_aqi_slider")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Activity Level selector
                Text(
                    text = "Activity Level:",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Light", "Moderate", "High").forEach { act ->
                        val isSelected = simActivity == act
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) JivaTealPrimary else Color(0xFFF1F5F9),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { simActivity = act }
                        ) {
                            Text(
                                text = act,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else JivaTextSecondary
                                ),
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Medication Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Medications Taken on Schedule",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Switch(
                        checked = simMedsTaken,
                        onCheckedChange = { simMedsTaken = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = JivaTealPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
