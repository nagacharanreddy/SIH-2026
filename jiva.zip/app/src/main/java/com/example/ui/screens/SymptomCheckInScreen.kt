package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.SymptomEntry
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun SymptomCheckInScreen(
    onSaveCheckIn: (SymptomEntry) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pain by remember { mutableFloatStateOf(1f) }
    var fatigue by remember { mutableFloatStateOf(2f) }
    var nausea by remember { mutableFloatStateOf(0f) }
    var breathing by remember { mutableFloatStateOf(1f) }
    var appetite by remember { mutableFloatStateOf(8f) }
    var sleepQuality by remember { mutableFloatStateOf(7f) }
    var mood by remember { mutableFloatStateOf(8f) }
    var notes by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }

    val evalStatus = remember(pain, fatigue, nausea, breathing) {
        val maxConcern = maxOf(pain, fatigue, nausea, breathing)
        when {
            maxConcern >= 8f -> "URGENT REVIEW"
            maxConcern >= 5f -> "REVIEW RECOMMENDED"
            maxConcern >= 3f -> "ATTENTION"
            else -> "STABLE"
        }
    }

    val statusColor = when (evalStatus) {
        "URGENT REVIEW" -> JivaRedCritical
        "REVIEW RECOMMENDED" -> JivaOrangeHighRisk
        "ATTENTION" -> JivaAmberAttention
        else -> JivaGreenHealthy
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                }
                Text(
                    text = "Daily Symptom Check-in",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Evaluation Preview Card
            GlassCard(
                cornerRadius = 20.dp,
                glowColor = statusColor,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CLINICAL EVALUATION STATUS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextSecondary,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = evalStatus,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = statusColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = if (evalStatus == "STABLE") "NORMAL" else "FLAGGED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sliders for 7 Parameters
            GlassCard(cornerRadius = 20.dp, modifier = Modifier.fillMaxWidth()) {
                SymptomSliderRow("Pain Severity", pain.toInt(), "0 (None) to 10 (Severe)") { pain = it }
                SymptomSliderRow("Fatigue Level", fatigue.toInt(), "0 (Energized) to 10 (Exhausted)") { fatigue = it }
                SymptomSliderRow("Nausea / Gastro", nausea.toInt(), "0 (None) to 10 (Severe)") { nausea = it }
                SymptomSliderRow("Breathing Difficulty", breathing.toInt(), "0 (Normal) to 10 (Short of Breath)") { breathing = it }
                SymptomSliderRow("Appetite", appetite.toInt(), "0 (Poor) to 10 (Excellent)") { appetite = it }
                SymptomSliderRow("Sleep Quality", sleepQuality.toInt(), "0 (Poor) to 10 (Restful)") { sleepQuality = it }
                SymptomSliderRow("Mood & Emotional State", mood.toInt(), "0 (Low) to 10 (Positive)") { mood = it }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Any specific notes for your doctor? (Optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                if (!isSubmitted) {
                    GlowButton(
                        text = "SUBMIT DAILY CHECK-IN",
                        onClick = {
                            val entry = SymptomEntry(
                                pain = pain.toInt(),
                                fatigue = fatigue.toInt(),
                                nausea = nausea.toInt(),
                                breathing = breathing.toInt(),
                                appetite = appetite.toInt(),
                                sleepQuality = sleepQuality.toInt(),
                                mood = mood.toInt(),
                                notes = notes,
                                overallStatus = evalStatus
                            )
                            onSaveCheckIn(entry)
                            isSubmitted = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "submit_symptom_checkin_btn"
                    )
                } else {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = JivaGreenLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JivaGreenHealthy)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Check-in Logged Successfully! Biometrics synced.",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = JivaGreenHealthy
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun SymptomSliderRow(
    title: String,
    value: Int,
    subtitle: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "$value / 10",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = JivaTealPrimary
                )
            )
        }
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary, fontSize = 11.sp)
        )
        Slider(
            value = value.toFloat(),
            onValueChange = onValueChange,
            valueRange = 0f..10f,
            steps = 9,
            colors = SliderDefaults.colors(
                thumbColor = JivaTealPrimary,
                activeTrackColor = JivaTealPrimary
            )
        )
    }
}
