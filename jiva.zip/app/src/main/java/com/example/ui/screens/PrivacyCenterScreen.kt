package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun PrivacyCenterScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var shareWithDoctor by remember { mutableStateOf(true) }
    var shareEmergency by remember { mutableStateOf(true) }
    var localEncryption by remember { mutableStateOf(true) }
    var showDataWipedMsg by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                }
                Text(
                    text = "Privacy & Data Shield",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3D Rotating Shield Hero Card
            GlassCard(
                cornerRadius = 24.dp,
                glowColor = JivaBlueDoctor,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "YOUR HEALTH DATA • YOUR SOVEREIGN CONTROL",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaBlueDoctor,
                        letterSpacing = 0.5.sp
                    )
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Zero Cloud Leakage • On-Device AI Engine",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )

                // 3D Shield Canvas
                Shield3DCanvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "All physiological baselines, ECG telemetry, symptom logs, and risk calculations are processed 100% locally within Android Room encrypted storage.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = JivaTextSecondary,
                        lineHeight = 18.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sharing Permissions
            SectionHeader(title = "Data Sharing Governance")

            GlassCard(cornerRadius = 20.dp, modifier = Modifier.fillMaxWidth()) {
                PrivacyToggleRow(
                    title = "Doctor Care Plan Sync",
                    desc = "Share encrypted telemetry summary with Dr. Ananya Roy",
                    checked = shareWithDoctor,
                    onCheckedChange = { shareWithDoctor = it }
                )
                Divider(color = Color(0x220284C7), modifier = Modifier.padding(vertical = 8.dp))

                PrivacyToggleRow(
                    title = "Emergency Contact Access",
                    desc = "Auto-share GPS & critical telemetry during SOS triggers",
                    checked = shareEmergency,
                    onCheckedChange = { shareEmergency = it }
                )
                Divider(color = Color(0x220284C7), modifier = Modifier.padding(vertical = 8.dp))

                PrivacyToggleRow(
                    title = "Hardware Keystore Encryption",
                    desc = "AES-256 local database encryption active",
                    checked = localEncryption,
                    onCheckedChange = { localEncryption = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Data Export & Wipe Card
            SectionHeader(title = "Data Export & Erasure")

            GlassCard(cornerRadius = 20.dp, modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = JivaTealPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export All Data (Encrypted JSON / FHIR)")
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { showDataWipedMsg = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Wipe Local Health Data from Device")
                }

                if (showDataWipedMsg) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Data storage reset confirmed.",
                        style = MaterialTheme.typography.bodySmall.copy(color = JivaGreenHealthy, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun PrivacyToggleRow(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text(text = desc, style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary))
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = JivaBlueDoctor
            )
        )
    }
}
