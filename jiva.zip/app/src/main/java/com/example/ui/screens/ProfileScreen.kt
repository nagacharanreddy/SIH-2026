package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.UserProfile
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    userProfile: UserProfile,
    isOffline: Boolean,
    onToggleOffline: (Boolean) -> Unit,
    onNavigatePrivacy: () -> Unit,
    onNavigateConditions: () -> Unit,
    onNavigateReports: () -> Unit,
    onNavigateDoctor: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Health Profile & Settings",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = JivaTextPrimary
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // User Identity Card
            GlassCard(
                cornerRadius = 24.dp,
                glowColor = JivaTealPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(
                                brush = Brush.linearGradient(
                                    listOf(JivaTealPrimary, JivaCyanAccent)
                                )
                            )
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userProfile.name.take(1),
                            style = MaterialTheme.typography.displayMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = userProfile.name,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${userProfile.gender} • ${userProfile.age} yrs • Height: ${userProfile.heightCm.toInt()}cm • Weight: ${userProfile.weightKg}kg",
                            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                        )
                        Text(
                            text = "Emergency: ${userProfile.emergencyContact}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = JivaTealDark,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Care Continuity Metric
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x80F1F5F9))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CARE CONTINUITY SCORE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextSecondary
                            )
                        )
                        Text(
                            text = "${userProfile.careContinuityScore}% Optimal",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaGreenHealthy
                            )
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = JivaGreenHealthy,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Offline Mode Toggle Card
            GlassCard(
                cornerRadius = 20.dp,
                glowColor = if (isOffline) JivaAmberAttention else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (isOffline) JivaAmberLight else JivaTealLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isOffline) Icons.Default.CloudOff else Icons.Default.CloudQueue,
                                contentDescription = null,
                                tint = if (isOffline) JivaAmberAttention else JivaTealPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Offline Operation Mode",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = if (isOffline) "Local Room risk engine active. Zero cloud dependencies." else "Connected mode active.",
                                style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                            )
                        }
                    }

                    Switch(
                        checked = isOffline,
                        onCheckedChange = onToggleOffline,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = JivaAmberAttention
                        ),
                        modifier = Modifier.testTag("offline_toggle_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Navigation Options
            SectionHeader(title = "Health Governance")

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ProfileNavOption("Privacy & Data Shield", "Encryption, consent & local storage", Icons.Default.Security, onNavigatePrivacy)
                ProfileNavOption("Conditions & Doctor Care Plan", "Prescription targets & protocols", Icons.Default.Assignment, onNavigateConditions)
                ProfileNavOption("Clinical Monitoring Reports", "14-day aggregated summaries", Icons.Default.Summarize, onNavigateReports)
                ProfileNavOption("Connected Doctor Teleconsult", "Physician direct channel", Icons.Default.MedicalServices, onNavigateDoctor)
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun ProfileNavOption(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    GlassCard(
        cornerRadius = 18.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(JivaTealLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = JivaTealPrimary, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary))
                }
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = JivaTextTertiary)
        }
    }
}
