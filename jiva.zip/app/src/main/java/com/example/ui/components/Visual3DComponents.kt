package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.RiskLevel
import com.example.ui.theme.*
import kotlin.math.*

// ==========================================
// 1. 3D PERSONAL HEALTH TWIN
// ==========================================
@Composable
fun HealthTwin3DCanvas(
    riskLevel: RiskLevel,
    heartRate: Int,
    spO2: Int,
    hrv: Int,
    temp: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "twinTransition")

    // Rotation angle for 3D rings
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "twinRotation"
    )

    // Breathing / Heartbeat pulse
    val heartbeatPeriod = (60000 / heartRate.coerceIn(50, 160)).toInt()
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(heartbeatPeriod / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "twinPulse"
    )

    // Dynamic state theme color
    val stateColor = when (riskLevel) {
        RiskLevel.LOW -> JivaGreenHealthy
        RiskLevel.MODERATE -> JivaAmberAttention
        RiskLevel.HIGH -> JivaOrangeHighRisk
        RiskLevel.CRITICAL -> JivaRedCritical
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2
            val cy = size.height / 2

            // 1. Ambient holographic backglow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        stateColor.copy(alpha = 0.25f),
                        JivaTealPrimary.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = Offset(cx, cy),
                    radius = size.minDimension * 0.48f
                ),
                radius = size.minDimension * 0.48f,
                center = Offset(cx, cy)
            )

            // 2. Stylized 3D Human Silhouette / Core Biometric Avatar
            val rad = Math.toRadians(rotationAngle.toDouble())
            val coreRadius = (size.minDimension * 0.24f) * pulseScale

            // Draw Silhouette Head & Torso with holographic glass gradients
            val headRadius = coreRadius * 0.38f
            val headCenter = Offset(cx, cy - coreRadius * 0.75f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, stateColor.copy(alpha = 0.6f), JivaTealPrimary.copy(alpha = 0.3f)),
                    center = headCenter,
                    radius = headRadius
                ),
                radius = headRadius,
                center = headCenter
            )

            // Torso & Heart Center
            val torsoPath = Path().apply {
                moveTo(cx - coreRadius * 0.55f, cy - coreRadius * 0.25f)
                cubicTo(
                    cx - coreRadius * 0.7f, cy + coreRadius * 0.4f,
                    cx - coreRadius * 0.4f, cy + coreRadius * 0.85f,
                    cx, cy + coreRadius * 0.95f
                )
                cubicTo(
                    cx + coreRadius * 0.4f, cy + coreRadius * 0.85f,
                    cx + coreRadius * 0.7f, cy + coreRadius * 0.4f,
                    cx + coreRadius * 0.55f, cy - coreRadius * 0.25f
                )
                close()
            }
            drawPath(
                path = torsoPath,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        stateColor.copy(alpha = 0.45f),
                        JivaTealPrimary.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    startY = cy - coreRadius * 0.3f,
                    endY = cy + coreRadius * 0.95f
                )
            )

            // Central Glowing Heart Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, stateColor, Color.Transparent),
                    center = Offset(cx, cy - coreRadius * 0.1f),
                    radius = coreRadius * 0.35f
                ),
                radius = coreRadius * 0.35f,
                center = Offset(cx, cy - coreRadius * 0.1f)
            )

            // 3. 3D Elliptical Orbital Rings (perspective transformed)
            val ringRadiusX = size.minDimension * 0.42f
            val ringRadiusY = size.minDimension * 0.16f

            for (i in 0..2) {
                val ringTilt = Math.toRadians((rotationAngle + i * 60.0))
                val cosTilt = cos(ringTilt).toFloat()
                val sinTilt = sin(ringTilt).toFloat()

                // Draw orbital ring
                drawOval(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            stateColor.copy(alpha = 0.1f),
                            stateColor.copy(alpha = 0.8f),
                            JivaCyanAccent.copy(alpha = 0.3f),
                            stateColor.copy(alpha = 0.1f)
                        ),
                        center = Offset(cx, cy)
                    ),
                    topLeft = Offset(cx - ringRadiusX, cy - ringRadiusY * (1f + 0.3f * i)),
                    size = Size(ringRadiusX * 2, ringRadiusY * 2 * (1f + 0.3f * i)),
                    style = Stroke(width = 1.6.dp.toPx())
                )

                // Draw orbiting particle nodes
                val particleAngle = ringTilt + Math.PI * 0.5
                val px = cx + (ringRadiusX * cos(particleAngle)).toFloat()
                val py = cy + (ringRadiusY * (1f + 0.3f * i) * sin(particleAngle)).toFloat()

                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = Offset(px, py)
                )
                drawCircle(
                    color = stateColor.copy(alpha = 0.6f),
                    radius = 7.dp.toPx(),
                    center = Offset(px, py)
                )

                // Glowing connection line to center
                drawLine(
                    color = stateColor.copy(alpha = 0.25f),
                    start = Offset(cx, cy),
                    end = Offset(px, py),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // 4. Floating Biomarker Metric Floating Nodes
            // Top-Left: Heart Rate
            drawMetricPill(
                scope = this,
                center = Offset(cx - ringRadiusX * 0.75f, cy - ringRadiusY * 2.2f),
                label = "$heartRate BPM",
                subLabel = "HEART",
                color = stateColor
            )

            // Top-Right: SpO2
            drawMetricPill(
                scope = this,
                center = Offset(cx + ringRadiusX * 0.75f, cy - ringRadiusY * 2.2f),
                label = "$spO2%",
                subLabel = "SpO₂",
                color = JivaCyanAccent
            )

            // Bottom-Left: HRV
            drawMetricPill(
                scope = this,
                center = Offset(cx - ringRadiusX * 0.8f, cy + ringRadiusY * 2.0f),
                label = "$hrv ms",
                subLabel = "HRV",
                color = JivaPurpleInfo
            )

            // Bottom-Right: Temp
            drawMetricPill(
                scope = this,
                center = Offset(cx + ringRadiusX * 0.8f, cy + ringRadiusY * 2.0f),
                label = "${String.format("%.1f", temp)}°C",
                subLabel = "TEMP",
                color = if (temp > 37.5f) JivaOrangeHighRisk else JivaGreenHealthy
            )
        }
    }
}

private fun drawMetricPill(
    scope: DrawScope,
    center: Offset,
    label: String,
    subLabel: String,
    color: Color
) {
    val pillW = 68.dp.value
    val pillH = 30.dp.value

    scope.drawRoundRect(
        color = Color(0xEEFFFFFF),
        topLeft = Offset(center.x - pillW / 2, center.y - pillH / 2),
        size = Size(pillW, pillH),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(15.dp.value, 15.dp.value)
    )
    scope.drawRoundRect(
        color = color.copy(alpha = 0.5f),
        topLeft = Offset(center.x - pillW / 2, center.y - pillH / 2),
        size = Size(pillW, pillH),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(15.dp.value, 15.dp.value),
        style = Stroke(width = 1.2.dp.value)
    )
    // Small glowing dot
    scope.drawCircle(
        color = color,
        radius = 3.dp.value,
        center = Offset(center.x - pillW / 2 + 10.dp.value, center.y)
    )
}

// ==========================================
// 2. 3D BEATING HEART ANIMATION
// ==========================================
@Composable
fun Heart3DCanvas(
    bpm: Int = 78,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "heartTransition")
    val cycleMs = (60000 / bpm.coerceIn(40, 180)).toInt()

    val scale by infiniteTransition.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = cycleMs
                0.90f at 0
                1.15f at (cycleMs * 0.20).toInt() using FastOutSlowInEasing
                0.96f at (cycleMs * 0.35).toInt()
                1.08f at (cycleMs * 0.50).toInt() using FastOutSlowInEasing
                0.90f at (cycleMs * 0.70).toInt()
                0.90f at cycleMs
            },
            repeatMode = RepeatMode.Restart
        ),
        label = "heartScale"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(cycleMs / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartGlow"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2
        val cy = size.height / 2
        val w = (size.minDimension * 0.45f) * scale

        // Glow Aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    JivaRedCritical.copy(alpha = glowAlpha),
                    Color(0xFFFDA4AF).copy(alpha = glowAlpha * 0.4f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = w * 1.5f
            ),
            radius = w * 1.5f,
            center = Offset(cx, cy)
        )

        // 3D Heart Path
        val heartPath = Path().apply {
            moveTo(cx, cy + w * 0.8f)
            cubicTo(
                cx - w * 1.2f, cy + w * 0.2f,
                cx - w * 1.1f, cy - w * 0.7f,
                cx - w * 0.5f, cy - w * 0.7f
            )
            cubicTo(
                cx - w * 0.1f, cy - w * 0.7f,
                cx, cy - w * 0.3f,
                cx, cy - w * 0.3f
            )
            cubicTo(
                cx, cy - w * 0.3f,
                cx + w * 0.1f, cy - w * 0.7f,
                cx + w * 0.5f, cy - w * 0.7f
            )
            cubicTo(
                cx + w * 1.1f, cy - w * 0.7f,
                cx + w * 1.2f, cy + w * 0.2f,
                cx, cy + w * 0.8f
            )
            close()
        }

        // Heart base gradient (3D depth shading)
        drawPath(
            path = heartPath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFFFB7185),
                    Color(0xFFE11D48),
                    Color(0xFF9F1239)
                ),
                start = Offset(cx - w, cy - w),
                end = Offset(cx + w, cy + w)
            )
        )

        // Specular 3D highlight
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.7f), Color.Transparent),
                center = Offset(cx - w * 0.4f, cy - w * 0.35f),
                radius = w * 0.35f
            ),
            radius = w * 0.35f,
            center = Offset(cx - w * 0.4f, cy - w * 0.35f)
        )
    }
}

// ==========================================
// 3. 3D DYNAMIC ECG WAVEFORM
// ==========================================
@Composable
fun ECGWaveformCanvas(
    heartRate: Int = 78,
    lineColor: Color = JivaGreenHealthy,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ecgTransition")
    val speed = (1800 - (heartRate * 8)).coerceIn(600, 2400)

    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(speed, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ecgOffset"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cy = h / 2

        // Background subtle grid
        val gridStep = 20.dp.toPx()
        var gx = 0f
        while (gx < w) {
            drawLine(
                color = Color(0x100284C7),
                start = Offset(gx, 0f),
                end = Offset(gx, h),
                strokeWidth = 1f
            )
            gx += gridStep
        }
        var gy = 0f
        while (gy < h) {
            drawLine(
                color = Color(0x100284C7),
                start = Offset(0f, gy),
                end = Offset(w, gy),
                strokeWidth = 1f
            )
            gy += gridStep
        }

        // Draw animated ECG P-Q-R-S-T curve
        val path = Path()
        val waveLen = w * 0.7f
        val offsetPx = waveOffset * waveLen

        for (seg in -1..2) {
            val startX = seg * waveLen - offsetPx

            path.moveTo(startX, cy)
            path.lineTo(startX + waveLen * 0.20f, cy)
            // P wave
            path.cubicTo(
                startX + waveLen * 0.23f, cy - h * 0.15f,
                startX + waveLen * 0.27f, cy - h * 0.15f,
                startX + waveLen * 0.30f, cy
            )
            path.lineTo(startX + waveLen * 0.35f, cy)
            // Q dip
            path.lineTo(startX + waveLen * 0.38f, cy + h * 0.12f)
            // R peak (tall spike)
            path.lineTo(startX + waveLen * 0.42f, cy - h * 0.44f)
            // S dip
            path.lineTo(startX + waveLen * 0.46f, cy + h * 0.22f)
            // Baseline
            path.lineTo(startX + waveLen * 0.50f, cy)
            // T wave
            path.cubicTo(
                startX + waveLen * 0.55f, cy - h * 0.22f,
                startX + waveLen * 0.65f, cy - h * 0.22f,
                startX + waveLen * 0.70f, cy
            )
            path.lineTo(startX + waveLen, cy)
        }

        // Glow pass
        drawPath(
            path = path,
            color = lineColor.copy(alpha = 0.3f),
            style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        // Crisp line pass
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

// ==========================================
// 4. 3D ROTATING GLOBE (ENVIRONMENT)
// ==========================================
@Composable
fun Globe3DCanvas(
    aqi: Int,
    temperature: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "globeTransition")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "globeRotation"
    )

    val atmosphereColor = if (aqi > 150) JivaOrangeHighRisk else JivaTealPrimary

    Canvas(modifier = modifier) {
        val cx = size.width / 2
        val cy = size.height / 2
        val r = size.minDimension * 0.38f

        // Atmospheric glowing aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    atmosphereColor.copy(alpha = 0.35f),
                    JivaCyanAccent.copy(alpha = 0.15f),
                    Color.Transparent
                ),
                center = Offset(cx, cy),
                radius = r * 1.35f
            ),
            radius = r * 1.35f,
            center = Offset(cx, cy)
        )

        // Base sphere with 3D gradient
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFE0F2FE),
                    Color(0xFFBAE6FD),
                    Color(0xFF0284C7)
                ),
                center = Offset(cx - r * 0.3f, cy - r * 0.3f),
                radius = r * 1.2f
            ),
            radius = r,
            center = Offset(cx, cy)
        )

        // 3D Longitude & Latitude Wireframe Rings
        val numMeridians = 6
        for (i in 0 until numMeridians) {
            val offsetDeg = rotationAngle + (i * (180f / numMeridians))
            val rad = Math.toRadians(offsetDeg.toDouble())
            val rx = r * abs(cos(rad)).toFloat().coerceAtLeast(2f)

            drawOval(
                color = Color.White.copy(alpha = 0.35f),
                topLeft = Offset(cx - rx, cy - r),
                size = Size(rx * 2, r * 2),
                style = Stroke(width = 1.2.dp.toPx())
            )
        }

        // Parallels (Latitudes)
        for (lat in listOf(-0.6f, -0.3f, 0f, 0.3f, 0.6f)) {
            val py = cy + r * lat
            val rw = sqrt((r * r - (r * lat) * (r * lat)).coerceAtLeast(0f))
            drawOval(
                color = Color.White.copy(alpha = 0.30f),
                topLeft = Offset(cx - rw, py - rw * 0.2f),
                size = Size(rw * 2, rw * 0.4f),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Location Marker Pin on Globe
        val markerRad = Math.toRadians(rotationAngle * 0.8)
        val mx = cx + (r * 0.65f * cos(markerRad)).toFloat()
        val my = cy + (r * 0.45f * sin(markerRad)).toFloat()

        drawCircle(
            color = Color.White,
            radius = 5.dp.toPx(),
            center = Offset(mx, my)
        )
        drawCircle(
            color = atmosphereColor,
            radius = 8.dp.toPx(),
            center = Offset(mx, my),
            style = Stroke(width = 2.dp.toPx())
        )

        // Floating environmental particulate cloud (if AQI elevated)
        if (aqi > 80) {
            val particleCount = (aqi / 15).coerceIn(8, 30)
            for (p in 0 until particleCount) {
                val pr = r * (1.1f + 0.2f * sin((rotationAngle + p * 30).toDouble()).toFloat())
                val pAngle = Math.toRadians((p * (360.0 / particleCount) + rotationAngle * 1.5))
                val px = cx + (pr * cos(pAngle)).toFloat()
                val py = cy + (pr * sin(pAngle)).toFloat()

                drawCircle(
                    color = if (aqi > 150) JivaOrangeHighRisk.copy(alpha = 0.6f) else JivaAmberAttention.copy(alpha = 0.5f),
                    radius = (2.5f + (p % 3)).dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }
    }
}

// ==========================================
// 5. 3D MEDICATION CAPSULE ANIMATION
// ==========================================
@Composable
fun Capsule3DCanvas(
    isTaken: Boolean,
    isDueNow: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "capsuleTransition")
    val wobbleAngle by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "capsuleWobble"
    )

    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "capsuleGlow"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2
        val cy = size.height / 2
        val capW = 75.dp.toPx()
        val capH = 34.dp.toPx()

        // Glow ring if due
        if (isDueNow && !isTaken) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(JivaCyanAccent.copy(alpha = glowAlpha), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = capW * 0.9f
                ),
                radius = capW * 0.9f,
                center = Offset(cx, cy)
            )
        }

        // Left Half of Capsule (Cyan / Green if taken)
        val leftColor = if (isTaken) JivaGreenHealthy else JivaTealPrimary
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    leftColor.copy(red = (leftColor.red + 0.2f).coerceAtMost(1f)),
                    leftColor,
                    leftColor.copy(blue = (leftColor.blue - 0.2f).coerceAtLeast(0f))
                )
            ),
            topLeft = Offset(cx - capW / 2, cy - capH / 2),
            size = Size(capW * 0.52f, capH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(capH / 2, capH / 2)
        )

        // Right Half of Capsule (White pearl)
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.White,
                    Color(0xFFF1F5F9),
                    Color(0xFFCBD5E1)
                )
            ),
            topLeft = Offset(cx, cy - capH / 2),
            size = Size(capW * 0.52f, capH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(capH / 2, capH / 2)
        )

        // Specular highlight band across capsule (3D glass reflection)
        drawLine(
            color = Color.White.copy(alpha = 0.6f),
            start = Offset(cx - capW * 0.35f, cy - capH * 0.25f),
            end = Offset(cx + capW * 0.35f, cy - capH * 0.25f),
            strokeWidth = 2.5.dp.toPx(),
            cap = StrokeCap.Round
        )

        // If Taken, draw crisp white checkmark in center
        if (isTaken) {
            val checkPath = Path().apply {
                moveTo(cx - 10.dp.toPx(), cy)
                lineTo(cx - 2.dp.toPx(), cy + 8.dp.toPx())
                lineTo(cx + 12.dp.toPx(), cy - 6.dp.toPx())
            }
            drawPath(
                path = checkPath,
                color = Color.White,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

// ==========================================
// 6. 3D DOCTOR CONNECTION VISUALIZER
// ==========================================
@Composable
fun DoctorConnection3DCanvas(
    isConnected: Boolean,
    isConnecting: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "doctorConnTransition")
    val packetProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "packetProgress"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cy = h / 2

        val patientX = w * 0.18f
        val doctorX = w * 0.82f
        val shieldX = w * 0.50f

        // 1. Connection line
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    JivaTealPrimary,
                    JivaCyanAccent,
                    if (isConnected) JivaGreenHealthy else JivaBlueDoctor
                )
            ),
            start = Offset(patientX, cy),
            end = Offset(doctorX, cy),
            strokeWidth = 2.dp.toPx()
        )

        // 2. Traveling data packets
        if (isConnecting || isConnected) {
            val pkt1X = patientX + (doctorX - patientX) * packetProgress
            drawCircle(
                color = Color.White,
                radius = 4.dp.toPx(),
                center = Offset(pkt1X, cy)
            )
            drawCircle(
                color = JivaCyanAccent.copy(alpha = 0.7f),
                radius = 8.dp.toPx(),
                center = Offset(pkt1X, cy)
            )

            val pkt2X = patientX + (doctorX - patientX) * ((packetProgress + 0.5f) % 1f)
            drawCircle(
                color = Color.White,
                radius = 3.5.dp.toPx(),
                center = Offset(pkt2X, cy)
            )
            drawCircle(
                color = JivaGreenHealthy.copy(alpha = 0.6f),
                radius = 7.dp.toPx(),
                center = Offset(pkt2X, cy)
            )
        }

        // 3. Patient Node (Left)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFE0F2FE), JivaTealPrimary),
                center = Offset(patientX, cy),
                radius = 24.dp.toPx()
            ),
            radius = 20.dp.toPx(),
            center = Offset(patientX, cy)
        )
        drawCircle(
            color = Color.White,
            radius = 20.dp.toPx(),
            center = Offset(patientX, cy),
            style = Stroke(width = 2.dp.toPx())
        )

        // 4. Central Data Shield (Middle)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, Color(0xFFBAE6FD)),
                center = Offset(shieldX, cy),
                radius = 18.dp.toPx()
            ),
            radius = 16.dp.toPx(),
            center = Offset(shieldX, cy)
        )
        drawCircle(
            color = JivaCyanAccent,
            radius = 16.dp.toPx(),
            center = Offset(shieldX, cy),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // 5. Doctor Node (Right)
        val docColor = if (isConnected) JivaGreenHealthy else JivaBlueDoctor
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, docColor),
                center = Offset(doctorX, cy),
                radius = 24.dp.toPx()
            ),
            radius = 20.dp.toPx(),
            center = Offset(doctorX, cy)
        )
        drawCircle(
            color = Color.White,
            radius = 20.dp.toPx(),
            center = Offset(doctorX, cy),
            style = Stroke(width = 2.dp.toPx())
        )
    }
}

// ==========================================
// 7. 3D PRIVACY SHIELD
// ==========================================
@Composable
fun Shield3DCanvas(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "shieldTransition")
    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(7000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shieldOrbit"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2
        val cy = size.height / 2
        val sw = size.minDimension * 0.38f

        // Ambient Aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(JivaBlueDoctor.copy(alpha = 0.3f), Color.Transparent),
                center = Offset(cx, cy),
                radius = sw * 1.5f
            ),
            radius = sw * 1.5f,
            center = Offset(cx, cy)
        )

        // 3D Glass Shield Path
        val shieldPath = Path().apply {
            moveTo(cx, cy - sw * 0.85f)
            cubicTo(
                cx + sw * 0.75f, cy - sw * 0.85f,
                cx + sw * 0.85f, cy - sw * 0.2f,
                cx + sw * 0.85f, cy + sw * 0.1f
            )
            cubicTo(
                cx + sw * 0.85f, cy + sw * 0.65f,
                cx, cy + sw * 1.05f,
                cx, cy + sw * 1.05f
            )
            cubicTo(
                cx, cy + sw * 1.05f,
                cx - sw * 0.85f, cy + sw * 0.65f,
                cx - sw * 0.85f, cy + sw * 0.1f
            )
            cubicTo(
                cx - sw * 0.85f, cy - sw * 0.2f,
                cx - sw * 0.75f, cy - sw * 0.85f,
                cx, cy - sw * 0.85f
            )
            close()
        }

        // Glass gradient fill
        drawPath(
            path = shieldPath,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0xE6FFFFFF),
                    Color(0xFFBAE6FD),
                    Color(0xFF60A5FA)
                ),
                start = Offset(cx - sw, cy - sw),
                end = Offset(cx + sw, cy + sw)
            )
        )

        // Shield border
        drawPath(
            path = shieldPath,
            color = Color.White,
            style = Stroke(width = 2.dp.toPx())
        )

        // Rotating Orbital Ring around Shield
        val rad = Math.toRadians(orbitAngle.toDouble())
        val rx = sw * 1.25f
        val ry = sw * 0.45f
        drawOval(
            color = JivaCyanAccent.copy(alpha = 0.4f),
            topLeft = Offset(cx - rx, cy - ry),
            size = Size(rx * 2, ry * 2),
            style = Stroke(width = 1.2.dp.toPx())
        )

        // Orbiting lock node
        val ox = cx + (rx * cos(rad)).toFloat()
        val oy = cy + (ry * sin(rad)).toFloat()
        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = Offset(ox, oy))
        drawCircle(color = JivaBlueDoctor, radius = 7.dp.toPx(), center = Offset(ox, oy))
    }
}

// ==========================================
// 8. ANIMATED CIRCULAR RISK GAUGE
// ==========================================
@Composable
fun RiskGaugeCanvas(
    score: Int,
    level: RiskLevel,
    modifier: Modifier = Modifier
) {
    val animatedScore by animateFloatAsState(
        targetValue = score.toFloat(),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "scoreAnim"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "gaugeParticle")
    val particleSweep by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "gaugeParticleSweep"
    )

    val gaugeColor = when (level) {
        RiskLevel.LOW -> JivaGreenHealthy
        RiskLevel.MODERATE -> JivaAmberAttention
        RiskLevel.HIGH -> JivaOrangeHighRisk
        RiskLevel.CRITICAL -> JivaRedCritical
    }

    Box(
        modifier = modifier.size(170.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2
            val cy = size.height / 2
            val radius = size.minDimension * 0.40f
            val strokeWidth = 12.dp.toPx()

            // Background Track
            drawArc(
                color = Color(0xFFE2E8F0),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(cx - radius, cy - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Value Progress Arc
            val sweep = (animatedScore / 100f) * 270f
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        JivaGreenHealthy,
                        JivaAmberAttention,
                        JivaOrangeHighRisk,
                        JivaRedCritical
                    ),
                    center = Offset(cx, cy)
                ),
                startAngle = 135f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(cx - radius, cy - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Revolving highlight particle along active arc
            val pSweep = 135f + (sweep * particleSweep)
            val pRad = Math.toRadians(pSweep.toDouble())
            val px = cx + (radius * cos(pRad)).toFloat()
            val py = cy + (radius * sin(pRad)).toFloat()

            drawCircle(
                color = Color.White,
                radius = 5.dp.toPx(),
                center = Offset(px, py)
            )
            drawCircle(
                color = gaugeColor,
                radius = 8.dp.toPx(),
                center = Offset(px, py),
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Center Score & Label
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "${animatedScore.toInt()}",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = JivaTextPrimary
                )
            )
            Text(
                text = level.label.uppercase(),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = gaugeColor,
                    letterSpacing = 0.5.sp
                )
            )
        }
    }
}

// ==========================================
// 9. FLOATING HEALTH PARTICLES
// ==========================================
@Composable
fun FloatingParticlesCanvas(
    particleColor: Color = JivaCyanAccent,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "particlesAnim")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particleTime"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val count = 16

        for (i in 0 until count) {
            val seed = i * 137.5f
            val speed = 0.5f + (i % 3) * 0.3f
            val py = (h - ((time * speed * h + seed * 10f) % h))
            val px = (seed * 7f + sin((time * 2 * Math.PI + i).toDouble()).toFloat() * 20f) % w
            val alpha = (0.2f + 0.4f * sin((time * Math.PI * 2 + i).toDouble()).toFloat()).coerceIn(0.1f, 0.7f)
            val pRadius = (2.dp + (i % 3).dp).toPx()

            drawCircle(
                color = particleColor.copy(alpha = alpha),
                radius = pRadius,
                center = Offset(abs(px), abs(py))
            )
        }
    }
}
