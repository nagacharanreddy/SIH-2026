package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val JivaLightColorScheme = lightColorScheme(
    primary = JivaTealPrimary,
    onPrimary = JivaTextInverse,
    primaryContainer = JivaTealLight,
    onPrimaryContainer = JivaTealDark,
    secondary = JivaCyanAccent,
    onSecondary = JivaTextInverse,
    background = JivaBgLight,
    onBackground = JivaTextPrimary,
    surface = JivaSurfaceLight,
    onSurface = JivaTextPrimary,
    surfaceVariant = JivaCardSurface,
    onSurfaceVariant = JivaTextSecondary,
    outline = JivaCardBorder,
    error = JivaRedCritical,
    onError = JivaTextInverse
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Mandated: Light Theme is strictly default for crisp, Apple Health + Futuristic medical aesthetic
    MaterialTheme(
        colorScheme = JivaLightColorScheme,
        typography = Typography,
        content = content
    )
}
