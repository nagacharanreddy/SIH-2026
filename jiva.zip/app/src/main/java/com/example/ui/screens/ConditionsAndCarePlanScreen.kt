package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CarePlan
import com.example.data.models.ConditionItem
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ConditionsAndCarePlanScreen(
    conditions: List<ConditionItem>,
    carePlan: CarePlan?,
    onAddCondition: (String, String, String) -> Unit,
    onAcknowledgeCarePlan: () -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var newCondName by remember { mutableStateOf("") }
    var newCondCategory by remember { mutableStateOf("Respiratory") }
    var newCondSeverity by remember { mutableStateOf("Moderate") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                    }
                    Text(
                        text = "Conditions & Care Plan",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // ==========================================
            // 1. MY CONDITIONS (DISEASE AGNOSTIC)
            // ==========================================
            SectionHeader(
                title = "Monitored Conditions",
                subtitle = "Disease-agnostic adaptive tracking profiles",
                actionLabel = "+ ADD CONDITION",
                onActionClick = { showAddDialog = true }
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                conditions.forEach { condition ->
                    ConditionCard(condition = condition)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ==========================================
            // 2. DOCTOR-APPROVED CARE PLAN
            // ==========================================
            SectionHeader(
                title = "Doctor-Approved Care Plan",
                subtitle = "Clinical protocol & telemetry threshold targets"
            )

            if (carePlan != null) {
                GlassCard(
                    cornerRadius = 24.dp,
                    glowColor = JivaTealPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = carePlan.title,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Prescribed by: ${carePlan.doctorName}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = JivaTealPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = JivaTealLight
                        ) {
                            Text(
                                text = "VERSION ${carePlan.version}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = JivaTealDark
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Clinical Physician Notes:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextSecondary
                        )
                    )
                    Text(
                        text = carePlan.doctorNotes,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = JivaTextPrimary,
                            lineHeight = 20.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Prescribed Medications Protocol:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextSecondary
                        )
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        carePlan.medications.forEach { med ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = JivaGreenHealthy, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = med,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Symptoms to Vigilantly Monitor:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextSecondary
                        )
                    )
                    Text(
                        text = carePlan.symptomsToMonitor.joinToString(" • "),
                        style = MaterialTheme.typography.bodySmall.copy(color = JivaOrangeHighRisk, fontWeight = FontWeight.SemiBold)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Acknowledge Care Plan Button
                    if (!carePlan.isAcknowledged) {
                        GlowButton(
                            text = "ACKNOWLEDGE CARE PLAN UPDATE",
                            onClick = onAcknowledgeCarePlan,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "ack_care_plan_btn"
                        )
                    } else {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = JivaGreenLight,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, tint = JivaGreenHealthy, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Care Plan Acknowledged by Patient",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = JivaGreenHealthy
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }

        // Add Condition Dialog
        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Add Health Condition", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = newCondName,
                            onValueChange = { newCondName = it },
                            label = { Text("Condition Name (e.g., Hypertension, COPD)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newCondCategory,
                            onValueChange = { newCondCategory = it },
                            label = { Text("Category (e.g., Cardiac, Respiratory)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newCondSeverity,
                            onValueChange = { newCondSeverity = it },
                            label = { Text("Severity (Mild, Moderate, Severe)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newCondName.isNotBlank()) {
                                onAddCondition(newCondName, newCondCategory, newCondSeverity)
                                showAddDialog = false
                                newCondName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = JivaTealPrimary)
                    ) {
                        Text("Add Condition")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun ConditionCard(condition: ConditionItem) {
    GlassCard(cornerRadius = 18.dp, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(JivaTealLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MedicalInformation,
                        contentDescription = null,
                        tint = JivaTealPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = condition.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${condition.category} • Diagnosed: ${condition.diagnosedDate}",
                        style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = JivaTealLight
            ) {
                Text(
                    text = condition.severity.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTealDark
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}
