package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.*
import com.example.data.local.JivaDatabase
import com.example.data.models.*
import com.example.data.repository.HealthRepository
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val database = remember { JivaDatabase.getDatabase(context) }
                val repository = remember { HealthRepository.getInstance(database.jivaDao()) }

                JivaApp(repository = repository)
            }
        }
    }
}

@Composable
fun JivaApp(repository: HealthRepository) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: "splash"

    // Repository state flows
    val vitals by repository.liveVitals.collectAsState()
    val environment by repository.liveEnvironment.collectAsState()
    val riskScore by repository.liveRiskScore.collectAsState()
    val userProfile by repository.userProfile.collectAsState()
    val baseline by repository.personalBaseline.collectAsState()
    val conditions by repository.conditions.collectAsState()
    val medications by repository.medications.collectAsState()
    val carePlan by repository.activeCarePlan.collectAsState()
    val alerts by repository.alerts.collectAsState()
    val timeline by repository.timeline.collectAsState()
    val isOffline by repository.isOfflineMode.collectAsState()
    val adherenceRate by repository.adherenceRate.collectAsState()

    var showDemoDialog by remember { mutableStateOf(false) }

    // Routes where top bar and bottom nav are visible
    val mainTabs = setOf("home", "insights", "environment", "alerts", "profile")
    val isMainTab = currentRoute in mainTabs

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (isMainTab) {
                GlassTopBar(
                    userName = userProfile.name,
                    isMonitoring = true,
                    isOffline = isOffline,
                    onAlertsClick = { navController.navigate("alerts") },
                    onProfileClick = { navController.navigate("profile") },
                    onDemoClick = { showDemoDialog = true }
                )
            }
        },
        bottomBar = {
            if (isMainTab) {
                GlassBottomNav(
                    currentRoute = currentRoute,
                    onTabSelected = { route ->
                        if (currentRoute != route) {
                            navController.navigate(route) {
                                popUpTo("home") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "splash",
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Splash & Welcome
            composable("splash") {
                SplashScreen(onNavigateNext = { navController.navigate("welcome") })
            }
            composable("welcome") {
                WelcomeScreen(
                    onGetStarted = { navController.navigate("onboarding_profile") },
                    onLogin = { navController.navigate("login") }
                )
            }

            // Auth
            composable("login") {
                LoginScreen(
                    onLoginSuccess = { navController.navigate("home") },
                    onNavigateSignUp = { navController.navigate("signup") }
                )
            }
            composable("signup") {
                SignUpScreen(
                    onSignUpSuccess = { navController.navigate("otp") },
                    onNavigateLogin = { navController.navigate("login") }
                )
            }
            composable("otp") {
                OtpScreen(onVerifySuccess = { navController.navigate("onboarding_profile") })
            }

            // Onboarding
            composable("onboarding_profile") {
                ProfileSetupScreen(onNext = { navController.navigate("onboarding_sensor") })
            }
            composable("onboarding_sensor") {
                SensorSetupScreen(onNext = { navController.navigate("onboarding_baseline") })
            }
            composable("onboarding_baseline") {
                BaselineSetupScreen(onFinish = {
                    navController.navigate("home") {
                        popUpTo("welcome") { inclusive = true }
                    }
                })
            }

            // Main 5 Tabs
            composable("home") {
                HomeScreen(
                    vitals = vitals,
                    environment = environment,
                    riskScore = riskScore,
                    alerts = alerts,
                    timeline = timeline,
                    isOffline = isOffline,
                    onNavigateTwin = { navController.navigate("twin") },
                    onNavigateCheckIn = { navController.navigate("checkin") },
                    onNavigateMedications = { navController.navigate("medications") },
                    onNavigateDoctor = { navController.navigate("doctor") },
                    onNavigateAlerts = { navController.navigate("alerts") },
                    onNavigateConditions = { navController.navigate("conditions") }
                )
            }
            composable("insights") {
                InsightsScreen(
                    riskScore = riskScore,
                    vitals = vitals,
                    environment = environment
                )
            }
            composable("environment") {
                EnvironmentScreen(environment = environment)
            }
            composable("alerts") {
                AlertsScreen(
                    alerts = alerts,
                    onResolveAlert = { alertId -> repository.resolveAlert(alertId) },
                    onNavigateEmergency = { navController.navigate("emergency") }
                )
            }
            composable("profile") {
                ProfileScreen(
                    userProfile = userProfile,
                    isOffline = isOffline,
                    onToggleOffline = { repository.toggleOfflineMode(it) },
                    onNavigatePrivacy = { navController.navigate("privacy") },
                    onNavigateConditions = { navController.navigate("conditions") },
                    onNavigateReports = { navController.navigate("reports") },
                    onNavigateDoctor = { navController.navigate("doctor") }
                )
            }

            // Secondary & Detailed Flows
            composable("twin") {
                HealthTwinScreen(
                    vitals = vitals,
                    baseline = baseline,
                    riskScore = riskScore,
                    environment = environment,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("conditions") {
                ConditionsAndCarePlanScreen(
                    conditions = conditions,
                    carePlan = carePlan,
                    onAddCondition = { name, cat, sev -> repository.addCondition(name, cat, sev) },
                    onAcknowledgeCarePlan = { repository.acknowledgeCarePlan() },
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("medications") {
                MedicationsScreen(
                    medications = medications,
                    adherenceRate = adherenceRate,
                    onTakeMedication = { medId -> repository.takeMedication(medId) },
                    onAddMedication = { name, dose, freq, time -> repository.addMedication(name, dose, freq, time) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("checkin") {
                SymptomCheckInScreen(
                    onSaveCheckIn = { entry -> repository.saveSymptomCheckIn(entry) },
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("doctor") {
                DoctorPortalScreen(
                    carePlan = carePlan,
                    onLaunchTeleconsultation = { navController.navigate("teleconsult") },
                    onNavigateReports = { navController.navigate("reports") },
                    onUpdateCarePlanFromDoctor = { title, meds, notes ->
                        repository.updateCarePlanFromDoctor(title, meds, notes)
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("teleconsult") {
                TeleconsultationScreen(
                    vitals = vitals,
                    onEndCall = { navController.popBackStack() }
                )
            }
            composable("reports") {
                ReportsScreen(
                    vitals = vitals,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("emergency") {
                EmergencyScreen(
                    vitals = vitals,
                    onSafeOverride = { navController.popBackStack() }
                )
            }
            composable("privacy") {
                PrivacyCenterScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }

    // SIH Demo Quick Switcher Dialog
    if (showDemoDialog) {
        DemoModeDialog(
            onDismiss = { showDemoDialog = false },
            onSelectScenario = { scenario -> repository.setDemoScenario(scenario) }
        )
    }
}
