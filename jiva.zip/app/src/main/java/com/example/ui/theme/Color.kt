package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Medical Futuristic Colors
val JivaTealPrimary = Color(0xFF0284C7)
val JivaTealLight = Color(0xFFE0F2FE)
val JivaTealDark = Color(0xFF0369A1)
val JivaCyanAccent = Color(0xFF06B6D4)

// Health State Semantic Colors
val JivaGreenHealthy = Color(0xFF10B981)
val JivaGreenLight = Color(0xFFD1FAE5)
val JivaAmberAttention = Color(0xFFF59E0B)
val JivaAmberLight = Color(0xFFFEF3C7)
val JivaOrangeHighRisk = Color(0xFFEA580C)
val JivaOrangeLight = Color(0xFFFFEDD5)
val JivaRedCritical = Color(0xFFEF4444)
val JivaRedLight = Color(0xFFFEE2E2)
val JivaBlueDoctor = Color(0xFF3B82F6)
val JivaPurpleInfo = Color(0xFF8B5CF6)

// Neutral Background & Surface for Premium Light Theme
val JivaBgLight = Color(0xFFF8FAFC)
val JivaSurfaceLight = Color(0xFFFFFFFF)
val JivaCardSurface = Color(0xF2FFFFFF)
val JivaCardBorder = Color(0x330284C7)
val JivaGlassSurface = Color(0xCCFFFFFF)
val JivaGlassBorder = Color(0x66BAE6FD)

// Text Colors
val JivaTextPrimary = Color(0xFF0F172A)
val JivaTextSecondary = Color(0xFF475569)
val JivaTextTertiary = Color(0xFF64748B)
val JivaTextInverse = Color(0xFFFFFFFF)

// Glow & Ambient Effects
val JivaGlowBlue = Color(0x400284C7)
val JivaGlowGreen = Color(0x4010B981)
val JivaGlowAmber = Color(0x40F59E0B)
val JivaGlowRed = Color(0x40EF4444)
