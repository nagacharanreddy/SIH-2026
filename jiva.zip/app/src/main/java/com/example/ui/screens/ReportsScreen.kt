package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.VitalReading
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ReportsScreen(
    vitals: VitalReading,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isExported by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                }
                Text(
                    text = "Clinical Monitoring Summary",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Report Header Card
            GlassCard(
                cornerRadius = 24.dp,
                glowColor = JivaTealPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "JIVA CLINICAL HEALTH SUMMARY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealPrimary,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = "Charan Sharma (Male, 34 yrs)",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Record Period: Last 14 Days • Generated: Today",
                            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = JivaTealLight
                    ) {
                        Text(
                            text = "VERIFIED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealDark
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Key Aggregate Metrics
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    ReportStat("AVG HEART RATE", "74 BPM", JivaGreenHealthy)
                    ReportStat("AVG SpO₂", "98.2%", JivaCyanAccent)
                    ReportStat("MED ADHERENCE", "94%", JivaTealPrimary)
                    ReportStat("ALERT COUNT", "1 Low", JivaAmberAttention)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Clinical Observations Card
            GlassCard(cornerRadius = 20.dp, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Physiological Observations & Baseline Comparison",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "• Heart rate dynamics remained predominantly in resting target range (60-85 BPM) with transient exertion elevation.\n" +
                            "• Respiratory oxygen saturation demonstrated 98% median consistency with zero severe desaturations.\n" +
                            "• Environmental heat exposure index averaged 28.5°C; patient hydration protocol maintained autonomic balance.\n" +
                            "• Daily symptom self-check-ins reported zero acute pain or severe shortness of breath.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = JivaTextPrimary,
                        lineHeight = 22.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Medical Disclaimer Box
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFFFEF3C7),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "CLINICAL DISCLAIMER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB45309),
                            letterSpacing = 0.5.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "This summary is generated from local biometric telemetry and patient-reported symptoms. It is designed to assist clinical discussions and is not an autonomous medical diagnosis.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF78350F),
                            lineHeight = 16.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Export Actions
            if (!isExported) {
                GlowButton(
                    text = "EXPORT PDF / SHARE WITH DOCTOR",
                    onClick = { isExported = true },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "export_report_btn"
                )
            } else {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = JivaGreenLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JivaGreenHealthy)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Report Ready! Encrypted PDF exported to local storage.",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaGreenHealthy
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun ReportStat(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = JivaTextSecondary,
                fontSize = 9.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = color
            )
        )
    }
}
