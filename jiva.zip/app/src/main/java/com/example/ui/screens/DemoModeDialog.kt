package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun DemoModeDialog(
    onDismiss: () -> Unit,
    onSelectScenario: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = JivaTealPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Demo Simulation Presets",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Instantly trigger diverse clinical & environmental states:",
                    style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                )

                Spacer(modifier = Modifier.height(4.dp))

                DemoOptionItem(
                    title = "1. Normal Healthy Baseline",
                    desc = "HR 74, SpO₂ 98%, Temp 36.8°C, AQI 42 (Low Risk: 18)",
                    icon = Icons.Default.Favorite,
                    color = JivaGreenHealthy,
                    onClick = {
                        onSelectScenario("normal")
                        onDismiss()
                    }
                )

                DemoOptionItem(
                    title = "2. Heat Stress & Cardiac Load",
                    desc = "HR 108, Temp 37.8°C, Heat Index 39.5°C (Moderate Risk: 62)",
                    icon = Icons.Default.WbSunny,
                    color = JivaAmberAttention,
                    onClick = {
                        onSelectScenario("heat")
                        onDismiss()
                    }
                )

                DemoOptionItem(
                    title = "3. Severe Pollution Airway Event",
                    desc = "AQI 280 Hazardous, SpO₂ 92%, Respiration 24 (High Risk: 76)",
                    icon = Icons.Default.Air,
                    color = JivaOrangeHighRisk,
                    onClick = {
                        onSelectScenario("pollution")
                        onDismiss()
                    }
                )

                DemoOptionItem(
                    title = "4. Critical Arrhythmia / Asthma Attack",
                    desc = "HR 138, SpO₂ 88%, BP 148/95 (Critical: 92 • Emergency SOS)",
                    icon = Icons.Default.Warning,
                    color = JivaRedCritical,
                    onClick = {
                        onSelectScenario("critical")
                        onDismiss()
                    }
                )

                DemoOptionItem(
                    title = "5. Offline Local Engine Mode",
                    desc = "Demonstrate zero cloud dependency & local Room database",
                    icon = Icons.Default.CloudOff,
                    color = JivaBlueDoctor,
                    onClick = {
                        onSelectScenario("offline")
                        onDismiss()
                    }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = JivaTealPrimary, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun DemoOptionItem(
    title: String,
    desc: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = color.copy(alpha = 0.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = JivaTextPrimary
                    )
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 10.sp,
                        color = JivaTextSecondary
                    )
                )
            }
        }
    }
}
