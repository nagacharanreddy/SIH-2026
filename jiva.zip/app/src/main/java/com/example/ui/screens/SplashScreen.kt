package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.RiskLevel
import com.example.ui.components.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onNavigateNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isReady by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(2200)
        isReady = true
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFF8FAFC),
                        Color(0xFFE0F2FE),
                        Color(0xFFBAE6FD)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        FloatingParticlesCanvas(
            particleColor = JivaCyanAccent,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // 3D Beating Heart in Glowing Orb
            Box(
                modifier = Modifier.size(140.dp),
                contentAlignment = Alignment.Center
            ) {
                Heart3DCanvas(
                    bpm = 78,
                    modifier = Modifier.size(110.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Animated ECG Line across center
            ECGWaveformCanvas(
                heartRate = 78,
                lineColor = JivaTealPrimary,
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .height(45.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // App Title: JIVA
            Text(
                text = "JIVA",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 42.sp,
                    letterSpacing = 4.sp,
                    color = JivaTealDark
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Tagline
            Text(
                text = "YOUR HEALTH. YOUR DATA. YOUR INTELLIGENT COMPANION.",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.2.sp,
                    color = JivaTextSecondary,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Secondary features
            Text(
                text = "Privacy-First • Personalized • Offline-Ready",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Medium,
                    color = JivaTealPrimary,
                    fontSize = 12.sp
                )
            )

            Spacer(modifier = Modifier.height(48.dp))

            GlassButton(
                text = "ENTER JIVA",
                onClick = onNavigateNext,
                icon = Icons.Default.ArrowForward,
                containerColor = JivaTealPrimary,
                testTag = "splash_enter_button"
            )
        }
    }
}

@Composable
fun WelcomeScreen(
    onGetStarted: () -> Unit,
    onLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight),
        contentAlignment = Alignment.Center
    ) {
        FloatingParticlesCanvas(
            particleColor = JivaCyanAccent.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "JIVA",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTealPrimary,
                        letterSpacing = 2.sp
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Your Health,\nAlways With You",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = JivaTextPrimary,
                        textAlign = TextAlign.Center
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Monitor your health, understand your environment, manage doctor care plans, and recognize concerning changes before they become emergencies.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = JivaTextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // 4 Feature Glass Cards
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    FeatureRow(
                        title = "PERSONALIZED",
                        desc = "Learns your individual baseline and disease-specific patterns.",
                        color = JivaTealPrimary
                    )
                    FeatureRow(
                        title = "PRIVACY FIRST",
                        desc = "Keeps sensitive health information stored locally on your device.",
                        color = JivaBlueDoctor
                    )
                    FeatureRow(
                        title = "OFFLINE READY",
                        desc = "Core monitoring and risk engine continue locally without internet.",
                        color = JivaGreenHealthy
                    )
                    FeatureRow(
                        title = "CONNECTED CARE",
                        desc = "Closed-loop continuity with your doctor and approved care plans.",
                        color = JivaPurpleInfo
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GlowButton(
                    text = "GET STARTED",
                    onClick = onGetStarted,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "welcome_get_started_btn"
                )

                Spacer(modifier = Modifier.height(12.dp))

                GlassButton(
                    text = "I ALREADY HAVE AN ACCOUNT",
                    onClick = onLogin,
                    containerColor = Color.White,
                    contentColor = JivaTealPrimary,
                    glowColor = JivaTealLight,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "welcome_login_btn"
                )

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun FeatureRow(
    title: String,
    desc: String,
    color: Color
) {
    GlassCard(
        cornerRadius = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(color, shape = androidx.compose.foundation.shape.CircleShape)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = color,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = JivaTextSecondary,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}
