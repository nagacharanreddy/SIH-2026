package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    vitals: VitalReading,
    environment: EnvironmentalReading,
    riskScore: RiskScoreData,
    alerts: List<AlertItem>,
    timeline: List<HealthTimelineEvent>,
    isOffline: Boolean,
    onNavigateTwin: () -> Unit,
    onNavigateCheckIn: () -> Unit,
    onNavigateMedications: () -> Unit,
    onNavigateDoctor: () -> Unit,
    onNavigateAlerts: () -> Unit,
    onNavigateConditions: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val statusGlow = when (riskScore.level) {
        RiskLevel.LOW -> JivaGreenHealthy
        RiskLevel.MODERATE -> JivaAmberAttention
        RiskLevel.HIGH -> JivaOrangeHighRisk
        RiskLevel.CRITICAL -> JivaRedCritical
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(
            particleColor = JivaCyanAccent.copy(alpha = 0.25f),
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // ==========================================
            // 1. HERO 3D HEALTH TWIN & HEALTH STATUS
            // ==========================================
            GlassCard(
                cornerRadius = 28.dp,
                glowColor = statusGlow,
                isAnimatedGlow = riskScore.level != RiskLevel.LOW,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "3D PERSONAL HEALTH TWIN",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealPrimary,
                                letterSpacing = 1.sp
                            )
                        )
                        Text(
                            text = if (riskScore.level == RiskLevel.LOW) "HEALTHY & STABLE" else "${riskScore.level.label.uppercase()} STATE",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextPrimary
                            )
                        )
                    }

                    StatusBadge(
                        status = riskScore.level.label,
                        level = riskScore.level
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Interactive 3D Holographic Twin Avatar Canvas
                HealthTwin3DCanvas(
                    riskLevel = riskScore.level,
                    heartRate = vitals.heartRate,
                    spO2 = vitals.spO2,
                    hrv = vitals.hrv,
                    temp = vitals.skinTemp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onNavigateTwin)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Risk Score summary row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x80FFFFFF))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "RISK SCORE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextSecondary
                            )
                        )
                        Text(
                            text = "${riskScore.currentScore} / 100",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = statusGlow
                            )
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when (riskScore.trend) {
                                RiskTrend.IMPROVING -> Icons.Default.TrendingDown
                                RiskTrend.STABLE -> Icons.Default.TrendingFlat
                                RiskTrend.RISING -> Icons.Default.TrendingUp
                            },
                            contentDescription = null,
                            tint = if (riskScore.trend == RiskTrend.RISING) JivaOrangeHighRisk else JivaGreenHealthy,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Risk ${riskScore.trend.name.lowercase().replaceFirstChar { it.uppercase() }}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = JivaTextSecondary
                            )
                        )
                    }

                    TextButton(onClick = onNavigateTwin) {
                        Text(
                            text = "EXPAND TWIN",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // 2. QUICK ACTIONS GLOW BUTTONS
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionButton(
                    title = "Daily Check-in",
                    icon = Icons.Default.Checklist,
                    accent = JivaTealPrimary,
                    onClick = onNavigateCheckIn,
                    modifier = Modifier.weight(1f),
                    testTag = "home_quick_checkin"
                )
                QuickActionButton(
                    title = "Medications",
                    icon = Icons.Default.Medication,
                    accent = JivaCyanAccent,
                    onClick = onNavigateMedications,
                    modifier = Modifier.weight(1f),
                    testTag = "home_quick_meds"
                )
                QuickActionButton(
                    title = "Care Plans",
                    icon = Icons.Default.Assignment,
                    accent = JivaPurpleInfo,
                    onClick = onNavigateConditions,
                    modifier = Modifier.weight(1f),
                    testTag = "home_quick_care_plans"
                )
                QuickActionButton(
                    title = "My Doctor",
                    icon = Icons.Default.MedicalServices,
                    accent = JivaBlueDoctor,
                    onClick = onNavigateDoctor,
                    modifier = Modifier.weight(1f),
                    testTag = "home_quick_doctor"
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ==========================================
            // 3. LIVE VITALS WITH 3D ECG
            // ==========================================
            SectionHeader(
                title = "Live Biometric Vitals",
                subtitle = "Continuously verified against personal baseline"
            )

            // Heart Rate & 3D Live ECG Card
            GlassCard(
                cornerRadius = 20.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF2F2)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = JivaRedCritical,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Heart Rate",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Resting Baseline: 60-85 BPM",
                                style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                            )
                        }
                    }

                    Text(
                        text = "${vitals.heartRate} BPM",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = JivaTextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Real-time moving ECG Waveform Canvas
                ECGWaveformCanvas(
                    heartRate = vitals.heartRate,
                    lineColor = if (vitals.heartRate > 100) JivaOrangeHighRisk else JivaGreenHealthy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x40F1F5F9))
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 4-Grid Biometrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                VitalMetricCard(
                    title = "Oxygen (SpO₂)",
                    value = "${vitals.spO2}%",
                    sub = "Baseline ≥95%",
                    icon = Icons.Default.Air,
                    accent = JivaCyanAccent,
                    modifier = Modifier.weight(1f)
                )
                VitalMetricCard(
                    title = "HRV Index",
                    value = "${vitals.hrv} ms",
                    sub = "Cardio Recovery",
                    icon = Icons.Default.Timeline,
                    accent = JivaPurpleInfo,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                VitalMetricCard(
                    title = "Skin Temp",
                    value = "${String.format("%.1f", vitals.skinTemp)}°C",
                    sub = "Normal: 36.8°C",
                    icon = Icons.Default.Thermostat,
                    accent = if (vitals.skinTemp > 37.5f) JivaOrangeHighRisk else JivaGreenHealthy,
                    modifier = Modifier.weight(1f)
                )
                VitalMetricCard(
                    title = "Blood Pressure",
                    value = "${vitals.bloodPressureSys}/${vitals.bloodPressureDia}",
                    sub = "Optimal mmHg",
                    icon = Icons.Default.Speed,
                    accent = JivaTealPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ==========================================
            // 4. ACTIVE ALERTS & RECENT TIMELINE
            // ==========================================
            if (alerts.any { !it.isResolved }) {
                val activeAlert = alerts.first { !it.isResolved }
                GlassCard(
                    cornerRadius = 20.dp,
                    glowColor = when (activeAlert.severity) {
                        RiskLevel.LOW -> JivaGreenHealthy
                        RiskLevel.MODERATE -> JivaAmberAttention
                        RiskLevel.HIGH -> JivaOrangeHighRisk
                        RiskLevel.CRITICAL -> JivaRedCritical
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = JivaOrangeHighRisk,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = activeAlert.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        StatusBadge(status = activeAlert.severity.label, level = activeAlert.severity)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = activeAlert.message,
                        style = MaterialTheme.typography.bodyMedium.copy(color = JivaTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Action: ${activeAlert.recommendedAction}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = JivaTealPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // Recent Journey Events
            SectionHeader(
                title = "Recent Health Journey",
                subtitle = "Automated chronological event logging"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                timeline.take(3).forEach { event ->
                    TimelineItemCard(event = event)
                }
            }

            Spacer(modifier = Modifier.height(80.dp)) // padding for bottom nav
        }
    }
}

@Composable
private fun QuickActionButton(
    title: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "quick_action_btn"
) {
    GlassCard(
        cornerRadius = 16.dp,
        modifier = modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = JivaTextPrimary
                )
            )
        }
    }
}

@Composable
private fun VitalMetricCard(
    title: String,
    value: String,
    sub: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(
        cornerRadius = 18.dp,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = JivaTextPrimary
                )
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp)
        )
        Text(
            text = sub,
            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary, fontSize = 11.sp)
        )
    }
}

@Composable
fun TimelineItemCard(event: HealthTimelineEvent) {
    GlassCard(
        cornerRadius = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(JivaTealPrimary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                )
            }
            Text(
                text = "${event.dateString}, ${event.timeString}",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = JivaTextTertiary,
                    fontSize = 10.sp
                )
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = event.description,
            style = MaterialTheme.typography.bodySmall.copy(
                color = JivaTextSecondary,
                fontSize = 12.sp
            )
        )
    }
}
