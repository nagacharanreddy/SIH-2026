package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EnvironmentalReading
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun EnvironmentScreen(
    environment: EnvironmentalReading,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.25f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Environmental Telemetry",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = JivaTextPrimary
                )
            )

            Text(
                text = "Ambient exposure & physiological stress correlation",
                style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3D Rotating Globe Hero Card
            GlassCard(
                cornerRadius = 28.dp,
                glowColor = if (environment.aqi > 150) JivaOrangeHighRisk else JivaTealPrimary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = JivaTealPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = environment.locationName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = JivaTealLight
                    ) {
                        Text(
                            text = "LIVE SENSOR FEED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTealDark,
                                fontSize = 9.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // 3D Globe Canvas
                Globe3DCanvas(
                    aqi = environment.aqi,
                    temperature = environment.temperature,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "HEAT INDEX",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextSecondary
                            )
                        )
                        Text(
                            text = "${String.format("%.1f", environment.heatIndex)}°C",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = JivaTextPrimary
                            )
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "AIR QUALITY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextSecondary
                            )
                        )
                        Text(
                            text = "${environment.aqi} AQI",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = if (environment.aqi > 100) JivaOrangeHighRisk else JivaGreenHealthy
                            )
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "UV INDEX",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = JivaTextSecondary
                            )
                        )
                        Text(
                            text = "${environment.uvIndex} (Mod)",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = JivaTealPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Environmental Metric Grid
            SectionHeader(title = "Local Environmental Factors")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EnvMetricCard(
                    title = "Temperature",
                    value = "${String.format("%.1f", environment.temperature)}°C",
                    sub = "Comfort Range 22-26°C",
                    icon = Icons.Default.Thermostat,
                    accent = JivaTealPrimary,
                    modifier = Modifier.weight(1f)
                )
                EnvMetricCard(
                    title = "Relative Humidity",
                    value = "${environment.humidity}%",
                    sub = "Optimal 40-60%",
                    icon = Icons.Default.WaterDrop,
                    accent = JivaCyanAccent,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EnvMetricCard(
                    title = "PM2.5 Particulate",
                    value = "${environment.pm25} µg/m³",
                    sub = "WHO Guideline ≤15",
                    icon = Icons.Default.Grain,
                    accent = if (environment.pm25 > 25) JivaAmberAttention else JivaGreenHealthy,
                    modifier = Modifier.weight(1f)
                )
                EnvMetricCard(
                    title = "Barometric Pressure",
                    value = "${environment.pressureHpa.toInt()} hPa",
                    sub = "Standard Atmospheric",
                    icon = Icons.Default.Compress,
                    accent = JivaPurpleInfo,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Environment + Physiology Correlation Matrix
            SectionHeader(
                title = "Physiological Stress Matrix",
                subtitle = "How current environment impacts your biological systems"
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                StressCorrelationCard(
                    title = "Heat Stress Index",
                    status = if (environment.heatIndex > 32f) "Moderate Stress" else "Low Stress",
                    desc = "Elevated ambient heat increases peripheral vasodilation and cardiac output demands.",
                    icon = Icons.Default.WbSunny,
                    accent = if (environment.heatIndex > 32f) JivaOrangeHighRisk else JivaGreenHealthy
                )
                StressCorrelationCard(
                    title = "Respiratory Airway Burden",
                    status = if (environment.aqi > 100) "Elevated" else "Minimal",
                    desc = "Particulate matter PM2.5 triggers pulmonary inflammation and bronchial constriction.",
                    icon = Icons.Default.Air,
                    accent = if (environment.aqi > 100) JivaAmberAttention else JivaTealPrimary
                )
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
private fun EnvMetricCard(
    title: String,
    value: String,
    sub: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(cornerRadius = 18.dp, modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = JivaTextPrimary
                )
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp)
        )
        Text(
            text = sub,
            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary, fontSize = 11.sp)
        )
    }
}

@Composable
private fun StressCorrelationCard(
    title: String,
    status: String,
    desc: String,
    icon: ImageVector,
    accent: Color
) {
    GlassCard(cornerRadius = 18.dp, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = accent.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = status,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = accent
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                )
            }
        }
    }
}
