package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.CarePlan
import com.example.data.models.RiskLevel
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun DoctorPortalScreen(
    carePlan: CarePlan?,
    onLaunchTeleconsultation: () -> Unit,
    onNavigateReports: () -> Unit,
    onUpdateCarePlanFromDoctor: (String, List<String>, String) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedRoleTab by remember { mutableStateOf(0) } // 0: Patient View, 1: Doctor Portal View
    var consentGiven by remember { mutableStateOf(true) }
    var showUpdatePlanDialog by remember { mutableStateOf(false) }

    var updatedTitle by remember { mutableStateOf("Cardiac & Pulmonary Adaptive Protocol v2.5") }
    var updatedMeds by remember { mutableStateOf("Salbutamol 100mcg, Atorvastatin 20mg, Metformin 500mg") }
    var updatedNotes by remember { mutableStateOf("Patient shows excellent adherence. Vitals stabilized post-inhaler adjustment.") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(JivaBgLight)
    ) {
        FloatingParticlesCanvas(particleColor = JivaCyanAccent.copy(alpha = 0.2f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = JivaTealPrimary)
                    }
                    Text(
                        text = "Connected Doctor Care",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = JivaTextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Role Switcher Tabs (Patient vs Doctor View)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Patient Connection", "Doctor Portal View (Clinical)").forEachIndexed { index, title ->
                    val isSelected = selectedRoleTab == index
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) JivaBlueDoctor else Color(0xFFF1F5F9),
                        modifier = Modifier.weight(1f)
                    ) {
                        TextButton(
                            onClick = { selectedRoleTab = index },
                            contentPadding = PaddingValues(vertical = 6.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else JivaTextSecondary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedRoleTab == 0) {
                // ==========================================
                // PATIENT VIEW: CONNECT TO DOCTOR
                // ==========================================
                GlassCard(
                    cornerRadius = 24.dp,
                    glowColor = JivaBlueDoctor,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(JivaTealLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MedicalServices, contentDescription = null, tint = JivaBlueDoctor, modifier = Modifier.size(26.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = carePlan?.doctorName ?: "Dr. Ananya Roy, MD",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Lead Pulmonologist & Critical Care • Apollo Health",
                                    style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = JivaGreenLight
                        ) {
                            Text(
                                text = "ONLINE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = JivaGreenHealthy
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 3D Doctor Connection Visualizer Canvas
                    DoctorConnection3DCanvas(
                        isConnected = consentGiven,
                        isConnecting = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(70.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Consent Checkbox Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = consentGiven,
                            onCheckedChange = { consentGiven = it },
                            colors = CheckboxDefaults.colors(checkedColor = JivaBlueDoctor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Authorize end-to-end encrypted sharing of local telemetry and risk trends.",
                            style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action Buttons
                    GlowButton(
                        text = "START VIDEO TELECONSULTATION",
                        onClick = onLaunchTeleconsultation,
                        accentColor = JivaBlueDoctor,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "start_teleconsult_btn"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    GlassButton(
                        text = "VIEW & EXPORT MONITORING REPORT",
                        onClick = onNavigateReports,
                        containerColor = Color.White,
                        contentColor = JivaBlueDoctor,
                        glowColor = JivaTealLight,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "view_reports_btn"
                    )
                }
            } else {
                // ==========================================
                // DOCTOR PORTAL CLINICAL DASHBOARD
                // ==========================================
                GlassCard(cornerRadius = 24.dp, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Physician Clinical Dashboard",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Active Patient Cohort (3 Monitored)",
                                style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary)
                            )
                        }

                        Button(
                            onClick = { showUpdatePlanDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = JivaBlueDoctor),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Update Care Plan", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Patient Roster Cards
                    PatientRosterCard("Charan Sharma", "34 yrs • Asthma / Arrhythmia", "Risk Score: 18 / 100", RiskLevel.LOW)
                    Spacer(modifier = Modifier.height(8.dp))
                    PatientRosterCard("Rajesh Kumar", "58 yrs • Post-CABG Cardiac", "Risk Score: 45 / 100", RiskLevel.MODERATE)
                    Spacer(modifier = Modifier.height(8.dp))
                    PatientRosterCard("Priya Patel", "42 yrs • Type-2 Diabetes / HTN", "Risk Score: 22 / 100", RiskLevel.LOW)
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }

        // Doctor Care Plan Update Modal
        if (showUpdatePlanDialog) {
            AlertDialog(
                onDismissRequest = { showUpdatePlanDialog = false },
                title = { Text("Update Patient Care Plan", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = updatedTitle,
                            onValueChange = { updatedTitle = it },
                            label = { Text("Protocol Title") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = updatedMeds,
                            onValueChange = { updatedMeds = it },
                            label = { Text("Medications (comma-separated)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = updatedNotes,
                            onValueChange = { updatedNotes = it },
                            label = { Text("Physician Clinical Notes") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val medList = updatedMeds.split(",").map { it.trim() }
                            onUpdateCarePlanFromDoctor(updatedTitle, medList, updatedNotes)
                            showUpdatePlanDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = JivaBlueDoctor)
                    ) {
                        Text("Publish Care Plan")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showUpdatePlanDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun PatientRosterCard(name: String, details: String, riskText: String, riskLevel: RiskLevel) {
    GlassCard(cornerRadius = 16.dp, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Text(text = details, style = MaterialTheme.typography.bodySmall.copy(color = JivaTextSecondary))
            }
            StatusBadge(status = riskText, level = riskLevel)
        }
    }
}
