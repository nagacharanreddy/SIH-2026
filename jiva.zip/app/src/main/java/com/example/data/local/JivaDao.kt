package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface JivaDao {
    @Query("SELECT * FROM vital_records ORDER BY timestamp DESC LIMIT 50")
    fun getRecentVitals(): Flow<List<LocalVitalRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVital(record: LocalVitalRecord)

    @Query("SELECT * FROM conditions")
    fun getAllConditions(): Flow<List<LocalCondition>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCondition(condition: LocalCondition)

    @Query("SELECT * FROM medications")
    fun getAllMedications(): Flow<List<LocalMedication>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedication(medication: LocalMedication)

    @Query("UPDATE medications SET status = :status WHERE id = :id")
    suspend fun updateMedicationStatus(id: String, status: String)

    @Query("SELECT * FROM care_plans")
    fun getAllCarePlans(): Flow<List<LocalCarePlan>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCarePlan(plan: LocalCarePlan)

    @Query("SELECT * FROM symptoms ORDER BY timestamp DESC")
    fun getAllSymptoms(): Flow<List<LocalSymptom>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSymptom(symptom: LocalSymptom)

    @Query("SELECT * FROM alerts ORDER BY id DESC")
    fun getAllAlerts(): Flow<List<LocalAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: LocalAlert)

    @Query("UPDATE alerts SET isResolved = 1 WHERE id = :id")
    suspend fun resolveAlert(id: String)

    @Query("SELECT * FROM timeline_events ORDER BY timestamp DESC")
    fun getAllTimelineEvents(): Flow<List<LocalTimelineEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimelineEvent(event: LocalTimelineEvent)
}
